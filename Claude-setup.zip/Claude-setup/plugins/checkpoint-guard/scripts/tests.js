'use strict';
// checkpoint-guard: decides which suites a staged change needs (from the project profile), runs them,
// records evidence. No skip switch exists by design: a failing or missing suite always blocks the commit.

const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const L = require('./lib');
const P = require('./profile');

// Source files and the test-file naming conventions of common stacks.
const SRC = /\.(ts|tsx|js|jsx|mjs|cjs|py|go|java|kt|cs|rs|rb|php|dart|swift|scala)$/;
const TEST_FILE = new RegExp([
  '\\.(spec|test)\\.(ts|tsx|js|jsx|mjs|cjs)$', '(^|/)test_[^/]+\\.py$', '_test\\.(py|go|dart)$', '(Test|Tests|IT)\\.(java|kt|scala)$',
  'Tests?\\.cs$', '_spec\\.rb$', '_test\\.rb$', 'Test\\.php$', 'Tests?\\.swift$', '(^|/)(__tests__|tests?|spec|specs)/',
].join('|'));
const NOT_SRC = /(^|\/)(index|main|app|__init__|mod|lib|Program|Startup|setup|conftest)\.[a-z]+$|\.(d\.ts|config\.[a-z]+)$|(^|\/)(migrations?|scripts?|tools?)\//i;
const SKIP_MARK = /^\+.*(\b(it|describe|test)\.(only|skip)\s*\(|\bx(it|describe|test)\s*\(|@pytest\.mark\.skip|@(Disabled|Ignore)\b|\[(Ignore|Skip)\b|t\.Skip\(|#\[ignore\]|\bskip:\s*true|--passWithNoTests)/m;

function stagedFiles(root) {
  return L.git(['diff', '--cached', '--name-status', '--diff-filter=ACMRD'], root).out
    .split('\n').filter(Boolean).map((l) => {
      const parts = l.split('\t');
      return { status: parts[0][0], file: L.norm(parts[parts.length - 1]) };
    });
}

// Longest package path that contains the file ("." is the repo root).
function packageFor(prof, file) {
  let best = null;
  for (const pk of prof.packages) {
    const p = pk.path === '.' ? '' : pk.path.replace(/\/$/, '') + '/';
    if ((p === '' || file.startsWith(p)) && (!best || p.length > best.prefix.length)) best = { ...pk, prefix: p };
  }
  return best;
}

function hasTestFor(root, file) {
  const base = path.basename(file).replace(/\.[a-z]+$/i, '');
  const re = new RegExp(`(^|/)(${base}\\.(spec|test)\\.[a-z]+|test_${base}\\.py|${base}_test\\.[a-z]+|${base}(Test|Tests|IT|_spec)\\.[a-z]+)$`, 'i');
  const tracked = L.git(['ls-files', '--cached'], root).out.split('\n');
  if (tracked.some((f) => re.test(L.norm(f)))) return true;
  // Rust and similar keep unit tests in the same file.
  try { return /#\[cfg\(test\)\]|\bmod tests\b/.test(fs.readFileSync(path.join(root, file), 'utf8')); } catch { return false; }
}

function plan(root, state) {
  const prof = P.load(root);
  const problems = [];
  if (!prof) return { files: [], suites: [], problems: ['this repo has no project profile yet. Run project onboarding (/checkpoint-guard:project-onboarding) first.'], highImpact: false };

  const files = stagedFiles(root);
  const pkgs = new Map();
  let highImpact = false;
  const hi = (prof.highImpact || []).map((h) => L.norm(h));

  for (const f of files) {
    if (L.isLockfile(f.file) && prof.lockfiles === 'never') problems.push(`\`${f.file}\` is staged, and this project never commits lockfiles: git restore --staged "${f.file}"`);
    if (L.excluded(f.file)) continue;
    if (hi.some((h) => f.file.includes(h))) highImpact = true;
    const pk = packageFor(prof, f.file);
    if (!pk) continue;
    pkgs.set(pk.path, pk);
    if (prof.newFileNeedsTest !== false && f.status === 'A' && SRC.test(f.file) && !TEST_FILE.test(f.file) && !NOT_SRC.test(f.file) && !hasTestFor(root, f.file)) {
      problems.push(`New file \`${f.file}\` has no test. Add its test to this commit.`);
    }
  }

  const diff = L.git(['diff', '--cached', '-U0'], root).out;
  if (SKIP_MARK.test(diff)) problems.push('The staged diff skips or narrows tests (.only/.skip/@Disabled/t.Skip/#[ignore]/--passWithNoTests). Tests may not be skipped.');

  if (highImpact) {
    for (const k of [...pkgs.keys()]) for (const r of (prof.related || {})[k] || []) {
      const pk = prof.packages.find((x) => x.path === r);
      if (pk) pkgs.set(pk.path, { ...pk, related: true });
    }
  }

  const suites = [];
  for (const [key, pk] of pkgs) {
    const dir = path.join(root, pk.path === '.' ? '' : pk.path);
    if (!pk.test) { problems.push(`\`${key}\` has no test command in the profile. Write tests for the touched flow and add the command.`); continue; }
    suites.push({ pkg: key, dir, cmd: pk.test });
    if (highImpact && pk.e2e) suites.push({ pkg: key, dir, cmd: pk.e2e });
    if (state.config.lint && pk.lint) suites.push({ pkg: key, dir, cmd: pk.lint });
  }
  return { files, suites, problems, highImpact };
}

function summarize(out, ok) {
  const lines = String(out).split('\n').map((l) => l.trim()).filter(Boolean);
  const hit = lines.reverse().find((l) => /(Tests?:|passed|failed|error|ok\s|FAIL|PASS|BUILD)/i.test(l));
  return hit ? hit.slice(0, 160) : ok ? 'ok' : 'failed';
}

function run(root, state) {
  const p = plan(root, state);
  const tree = L.git(['write-tree'], root).out;
  const deadline = Date.now() + (state.config.timeoutMin || 10) * 60000;
  const results = [];
  let log = `checkpoint-guard test run · ${L.stamp()} · tree ${tree}\nhigh-impact: ${p.highImpact}\n\n`;
  let ok = p.problems.length === 0;

  if (ok) {
    for (const s of p.suites) {
      const left = deadline - Date.now();
      if (left <= 0) { ok = false; results.push({ ...s, ok: false, summary: 'not run: time limit reached' }); continue; }
      const r = cp.spawnSync(s.cmd, { cwd: s.dir, shell: true, encoding: 'utf8', timeout: left, env: { ...process.env, CI: 'true' }, maxBuffer: 64 * 1024 * 1024 });
      const out = (r.stdout || '') + (r.stderr || '');
      const passed = r.status === 0;
      if (!passed) ok = false;
      results.push({ pkg: s.pkg, cmd: s.cmd, ok: passed, summary: r.error && r.error.code === 'ETIMEDOUT' ? 'timed out' : summarize(out, passed) });
      log += `===== ${s.pkg} · ${s.cmd} · ${passed ? 'PASS' : 'FAIL'} =====\n${out}\n\n`;
    }
  }

  const dir = path.join(L.stateDir(root), 'pending');
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'tests.txt'), log + (p.problems.length ? 'BLOCKED:\n- ' + p.problems.join('\n- ') + '\n' : ''));
  L.writeJSON(path.join(dir, 'tests.json'), { tree, ok, results, problems: p.problems, at: L.stamp() });
  return { tree, ok, results, problems: p.problems };
}

function cached(root) {
  const r = L.readJSON(path.join(L.stateDir(root), 'pending', 'tests.json'), null);
  const tree = L.git(['write-tree'], root).out;
  return r && r.ok && r.tree === tree ? r : null;
}

module.exports = { plan, run, cached, stagedFiles };
