#!/usr/bin/env node
'use strict';
// checkpoint-guard git hooks: pre-commit, commit-msg, post-commit, pre-push.
// Installed per repo by `node cp.js install`. They check, block and log; they never commit or push.

const fs = require('fs');
const path = require('path');
const L = require('./lib');
const T = require('./tests');
const B = require('./book');
const R = require('./review');

const root = L.repoRoot(process.cwd());
const hook = process.argv[2];

function fail(title, lines) {
  process.stderr.write(`\n✋ checkpoint-guard: ${title}\n${(lines || []).map((l) => '   - ' + l).join('\n')}\n\n`);
  process.exit(1);
}

function preCommit() {
  const s = L.loadState(root);
  const br = L.branch(root);
  if (L.isProtected(br)) fail(`"${br}" is a protected branch; never commit here.`, [`git switch -c ${L.CFG.branchPrefix}<name>`]);
  if (!L.FEATURE_BRANCH.test(br)) fail(`commits are only allowed on ${L.CFG.branchPrefix}<name> branches (current: ${br}).`, [`git switch -c ${L.CFG.branchPrefix}<name>`]);
  if (!s.feature || s.feature.status !== 'active') fail('no feature is started for checkpoints.', ['Agree the feature name and 4 quarter names, then: node cp.js feature start "<name>" --quarters "Q1|Q2|Q3|Q4"']);
  if (s.feature.branch !== br) fail(`this branch (${br}) is not the active feature's branch (${s.feature.branch}).`);
  if (!s.day || s.day.closed) fail('no working day is open.', ['Confirm a new day with the user, then: node cp.js day new']);

  const st = L.stagedLines(root);
  const ex = s.oversize && !s.oversize.used ? s.oversize : null;
  if (st.total > L.HARD) fail(`this commit changes ${st.total} lines; the absolute maximum is ${L.HARD}. Split it into smaller working commits.`);
  if (st.total > L.LIMIT && !(ex && st.total <= ex.limit)) {
    fail(`this commit changes ${st.total} lines (limit ${L.LIMIT}). Split it into smaller working commits.`, [
      `Edge/critical case only: the user may approve up to ${L.HARD} with  node cp.js allow-oversize <lines> "<reason>"`,
    ]);
  }

  const reuse = T.cached(root);
  const r = reuse || T.run(root, s);
  if (r.problems && r.problems.length) fail('commit blocked before tests:', r.problems);
  if (!r.ok) fail('tests failed. Nothing is committed until every required suite passes.', [
    ...r.results.filter((x) => !x.ok).map((x) => `${x.pkg} · ${x.cmd} · ${x.summary}`),
    `Full output: ${path.join(L.stateDir(root), 'pending', 'tests.txt')}`,
  ]);
  process.stdout.write(`checkpoint-guard: ${st.total} lines · tests passed${reuse ? ' (same tree as the last run)' : ''}\n`);
}

const ATTRIBUTION = [
  /^co-authored-by:/im,
  /^(assisted|generated|ai-assisted|signed-off)-by:.*(claude|anthropic|cursor|openai|gpt|copilot|gemini|agent|bot)/im,
  /generated (with|by)\s+\[?(claude|cursor|copilot|chatgpt|gpt|gemini|codex|an? ai|ai)/i,
  /noreply@anthropic\.com/i,
  /claude\.(ai|com)\/(code|claude-code)/i,
  /🤖/,
];

function commitMsg() {
  const text = fs.readFileSync(process.argv[3], 'utf8').split('\n').filter((l) => !l.startsWith('#')).join('\n');
  const title = text.split('\n')[0].trim();
  if (!title) fail('the commit needs a title line.');
  const hit = ATTRIBUTION.find((r) => r.test(text));
  if (hit) fail('commit messages must be plain: no AI or agent attribution lines (Co-Authored-By, "Generated with …", agent names).', ['Remove the line and commit again.']);
  if (title.length > 72) process.stderr.write(`checkpoint-guard: note, the title is ${title.length} characters; 72 or fewer reads best.\n`);
}

function postCommit() {
  const s = L.loadState(root);
  if (!s.feature || !s.day) return;
  const sha = L.git(['rev-parse', 'HEAD'], root).out;
  const short = sha.slice(0, 7);
  const title = L.git(['log', '-1', '--format=%s'], root).out;
  const body = L.git(['log', '-1', '--format=%b'], root).out;
  const stat = L.countNumstat(L.git(['show', '--numstat', '--format=', 'HEAD'], root).out);
  const treeHead = L.git(['rev-parse', 'HEAD^{tree}'], root).out;
  const pend = path.join(L.stateDir(root), 'pending');
  const res = L.readJSON(path.join(pend, 'tests.json'), { ok: false, results: [], tree: null });
  const testsOk = res.ok && res.tree === treeHead;

  const f = s.feature;
  const id = `CP-${L.pad(f.nextCp, 3)}`;
  const rb = s.pendingRollback && s.pendingRollback.method === 'revert' ? s.pendingRollback : null;
  const fileName = rb ? `${id}_rollback-to-${L.slug(rb.to)}.md` : `${id}_${L.slug(title)}.md`;
  const tag = `cp/${f.id}/${id}`;
  const dDir = L.dayDir(root, s);

  // A commit that skipped the gates (e.g. --no-verify) never becomes a checkpoint, and pre-push refuses it.
  if (!testsOk) {
    B.appendDay(root, s, `- ${L.istNow().time} · ⚠️ ${short} "${title}" was committed without passing the gates. Not a checkpoint; it cannot be pushed. Undo with: git reset --soft HEAD~1`);
    process.stderr.write(`\n⚠️  checkpoint-guard: ${short} skipped the commit gates, so it is NOT a checkpoint and pre-push will refuse it.\n   Undo it (keeps your changes): git reset --soft HEAD~1\n\n`);
    return;
  }

  let evidence = null;
  if (fs.existsSync(path.join(pend, 'tests.txt'))) {
    evidence = path.join(dDir, 'evidence', `${id}_tests.txt`);
    fs.mkdirSync(path.dirname(evidence), { recursive: true });
    fs.copyFileSync(path.join(pend, 'tests.txt'), evidence);
  }
  const ex = s.oversize && !s.oversize.used && stat.total > L.LIMIT ? s.oversize : null;
  const entry = {
    id, fileName, title, body, sha: short, tag, branch: L.branch(root), type: rb ? 'rollback' : 'checkpoint',
    timestamp: L.stamp(), lines: stat.total, files: stat.files,
    added: stat.files.reduce((a, x) => a + x.added, 0), deleted: stat.files.reduce((a, x) => a + x.deleted, 0),
    tests: res.tree === treeHead ? res.results : [], testsOk, evidence, exception: ex, rollback: rb,
  };
  const file = B.writeCheckpoint(root, s, entry);
  L.git(['tag', tag, sha], root);

  f.checkpoints.push({ id, title, sha, tag, quarter: f.currentQuarter, date: s.day.date, lines: stat.total, testsOk, pushed: false, file: B.rel(root, file) });
  if (testsOk) f.lastGood = `${id} (${short})`;
  f.nextCp += 1;
  if (ex) s.oversize.used = true;
  if (rb) s.pendingRollback = null;
  s.nudged = 0;
  B.syncRegistry(s);
  L.saveState(root, s);
  B.appendDay(root, s, `- ${entry.timestamp.slice(11, 19)} · [${id}](${L.norm(path.relative(dDir, file))}) · ${title} · ${stat.total} lines · tests ${testsOk ? '✅' : '❌'}`);
  B.writeFeature(root, s);
  try { fs.rmSync(pend, { recursive: true, force: true }); } catch {}
  process.stdout.write(`checkpoint-guard: ${id} recorded · ${B.rel(root, file)}\n`);
}

function prePush() {
  const input = fs.readFileSync(0, 'utf8').split('\n').filter(Boolean);
  const ZERO = /^0+$/;
  const problems = [];
  for (const line of input) {
    const [, localSha, remoteRef, remoteSha] = line.split(' ');
    const name = remoteRef.replace(/^refs\/heads\//, '');
    if (!L.FEATURE_BRANCH.test(name)) { problems.push(`pushing to "${name}" is not allowed; only ${L.CFG.branchPrefix}<name> branches.`); continue; }
    if (ZERO.test(localSha)) { problems.push(`deleting remote branch "${name}" is not allowed from here.`); continue; }
    if (!ZERO.test(remoteSha)) {
      if (!L.git(['merge-base', '--is-ancestor', remoteSha, localSha], root).ok) {
        problems.push(`this push rewrites history on "${name}" (force push). Use git revert for pushed commits.`);
        continue;
      }
    }
    const range = ZERO.test(remoteSha) ? [localSha, '--not', '--remotes'] : [`${remoteSha}..${localSha}`];
    const shas = L.git(['rev-list', ...range], root).out.split('\n').filter(Boolean);
    for (const sha of shas) if (!L.cpTagFor(root, sha)) problems.push(`commit ${sha.slice(0, 7)} has no checkpoint (it did not pass the commit gate).`);
    if (shas.length && !R.passed(root, localSha)) {
      problems.push(`no PASS review for ${localSha.slice(0, 7)} (rule 3.9). Run cp.js review scope, then /code-review and /security-review on our changes only, then cp.js review record --file <report.md>.`);
    }
  }
  if (problems.length) fail('push blocked:', problems);
}

try {
  if (!root) process.exit(0);
  if (hook === 'pre-commit') preCommit();
  else if (hook === 'commit-msg') commitMsg();
  else if (hook === 'post-commit') postCommit();
  else if (hook === 'pre-push') prePush();
} catch (e) {
  if (hook === 'post-commit') { process.stderr.write(`checkpoint-guard: could not write the checkpoint: ${e.message}\nRun: node cp.js repair\n`); process.exit(0); }
  fail(`internal error, so the ${hook} check could not run: ${e.message}`);
}
