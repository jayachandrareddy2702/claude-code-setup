'use strict';
// claude-kit machine settings (kit.json). Every value has a default, so the kit works before setup.
// The kit folder is found from CLAUDE_KIT (set by the installer in ~/.claude/settings.json) or by
// walking up from this file (when the scripts run straight from the kit, e.g. from git hooks).

const fs = require('fs');
const os = require('os');
const path = require('path');

const DEFAULTS = {
  version: 1,
  timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
  pushTime: '18:00',                 // mandatory end-of-day push
  reminderTime: '17:45',             // desktop reminder
  reminderDays: ['MON', 'TUE', 'WED', 'THU', 'FRI'],
  branchPrefix: 'feature/',
  protectedBranches: ['main', 'master', 'develop', 'release/*'],
  budget: { nudge: 400, limit: 440, hard: 480 },
  model: 'opusplan',
  workspaceRoots: [],
  git: { name: '', email: '' },
  headroom: false,
  backup: { keepDays: 7, time: '13:00' },
  lint: true,
  testTimeoutMin: 10,
};

function isKit(dir) {
  const m = path.join(dir, '.claude-plugin', 'marketplace.json');
  try { return JSON.parse(fs.readFileSync(m, 'utf8')).name === 'claude-kit'; } catch { return false; }
}

function kitRoot() {
  if (process.env.CLAUDE_KIT && isKit(process.env.CLAUDE_KIT)) return path.resolve(process.env.CLAUDE_KIT);
  let d = __dirname;
  for (let i = 0; i < 6; i++) { if (isKit(d)) return d; const up = path.dirname(d); if (up === d) break; d = up; }
  return null;
}

function merge(a, b) {
  const out = { ...a };
  for (const [k, v] of Object.entries(b || {})) out[k] = v && typeof v === 'object' && !Array.isArray(v) && a[k] && typeof a[k] === 'object' ? { ...a[k], ...v } : v;
  return out;
}

function load() {
  const root = kitRoot();
  let user = {};
  if (root) { try { user = JSON.parse(fs.readFileSync(path.join(root, 'kit.json'), 'utf8')); } catch {} }
  const cfg = merge(DEFAULTS, user);
  cfg.root = root;
  cfg.home = os.homedir();
  return cfg;
}

// Clock in the configured timezone.
function now(cfg) {
  const tz = (cfg || load()).timezone;
  const p = new Intl.DateTimeFormat('en-GB', {
    timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false, timeZoneName: 'short',
  }).formatToParts(new Date()).reduce((o, x) => ((o[x.type] = x.value), o), {});
  return { date: `${p.year}-${p.month}-${p.day}`, time: `${p.hour}:${p.minute}:${p.second}`, hour: +p.hour, minute: +p.minute, tz: p.timeZoneName || tz };
}

const toMin = (hhmm) => { const [h, m] = String(hhmm).split(':').map(Number); return h * 60 + (m || 0); };

function globToRe(g) {
  return new RegExp('^' + String(g).replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*') + '$');
}

module.exports = { DEFAULTS, load, kitRoot, isKit, now, toMin, globToRe };
