#!/usr/bin/env node
'use strict';
// checkpoint-guard Claude Code hooks. Keeps the user in control: every commit, push, reset,
// revert and cp.js call needs the user's approval; bypass attempts are refused.
// Usage: node claude-hook.js <pre-edit|post-edit|pre-bash|post-bash|session-start|prompt>

const fs = require('fs');
const path = require('path');
const L = require('./lib');

const CP = L.norm(path.join(__dirname, 'cp.js'));
const event = process.argv[2];
let input = {};
try { input = JSON.parse(fs.readFileSync(0, 'utf8') || '{}'); } catch {}

const out = (o) => process.stdout.write(JSON.stringify(o));
const deny = (reason) => out({ hookSpecificOutput: { hookEventName: 'PreToolUse', permissionDecision: 'deny', permissionDecisionReason: `checkpoint-guard: ${reason}` } });
const ask = (reason) => out({ hookSpecificOutput: { hookEventName: 'PreToolUse', permissionDecision: 'ask', permissionDecisionReason: `checkpoint-guard: ${reason}` } });
const context = (name, text) => out({ hookSpecificOutput: { hookEventName: name, additionalContext: `checkpoint-guard: ${text}` } });

function existingDir(p) {
  let d = p;
  while (d && !fs.existsSync(d)) { const up = path.dirname(d); if (up === d) return null; d = up; }
  return d && fs.statSync(d).isDirectory() ? d : path.dirname(d);
}

function rootFor(p) { const d = existingDir(p); return d ? L.repoRoot(d) : null; }

function preEdit() {
  const ti = input.tool_input || {};
  const target = ti.file_path || ti.notebook_path;
  if (!target) return;
  const abs = path.resolve(input.cwd || process.cwd(), target);
  const n = L.norm(abs).toLowerCase();
  if (/\/\.git\/(hooks|checkpoint-guard)(\/|$)/.test(n)) return deny('the git hooks and checkpoint state are off limits.');
  const root = rootFor(abs);
  if (!L.isInstalled(root)) return;
  if (n.includes('/.git/')) return deny('files inside .git are off limits.');
  if (n.includes('/docs/checkpoints/')) return deny('the checkpoint book is written by the hooks and cp.js only.');
  const s = L.loadState(root);
  const w = L.workingLines(root).total;
  const ex = s.oversize && !s.oversize.used ? s.oversize : null;
  if (w >= L.HARD) return deny(`${w} uncommitted lines, at the absolute maximum (${L.HARD}). Stop and ask the user to commit a checkpoint (or split the work) before any more edits.`);
  if (w >= L.LIMIT && !(ex && w < ex.limit)) {
    return deny(`${w} uncommitted lines reached the ${L.LIMIT}-line limit. Stop editing and tell the user: "We hit ${w} lines of changes; a checkpoint commit is needed before going ahead." Only for an edge/critical case may the user approve up to ${L.HARD} with: node "${CP}" allow-oversize <lines> "<reason>".`);
  }
}

function postEdit() {
  const ti = input.tool_input || {};
  const target = ti.file_path || ti.notebook_path;
  if (!target) return;
  const root = rootFor(path.resolve(input.cwd || process.cwd(), target));
  if (!L.isInstalled(root)) return;
  const w = L.workingLines(root).total;
  if (w < L.NUDGE) return;
  const s = L.loadState(root);
  const level = Math.floor(w / 20) * 20;
  if ((s.nudged || 0) >= level) return;
  s.nudged = level;
  L.saveState(root, s);
  context('PostToolUse', `uncommitted changes are now ${w} lines (limit ${L.LIMIT}). Finish the current working step, then stop and tell the user: "We hit ${w} lines of changes; a checkpoint commit is needed before going ahead." Run the required tests and offer the commit options from rule 3.8.`);
}

const BYPASS = [
  [/--no-verify\b/, '--no-verify skips the checkpoint gates'],
  [/\bgit\b[^|;&\n]*\bcommit\b[^|;&\n]*\s-[a-zA-Z]*n[a-zA-Z]*(\s|$)/, 'git commit -n skips the checkpoint gates'],
  [/core\.hooksPath/i, 'changing core.hooksPath disables the checkpoint gates'],
  [/\bHUSKY\s*=\s*0\b/, 'HUSKY=0 disables hooks'],
  [/\.git[\\/](hooks|checkpoint-guard)/i, 'the hooks and checkpoint state are off limits'],
  [/docs[\\/]checkpoints/i, 'the checkpoint book is written by the hooks and cp.js only'],
  [/--passWithNoTests/, 'tests may not be skipped'],
  [/\bgit\b[^|;&\n]*\bpush\b[^|;&\n]*(\s--force(-with-lease)?\b|\s-f\b|\s\+\S)/, 'force pushes rewrite shared history; use git revert'],
  [/\bgit\b[^|;&\n]*\btag\b[^|;&\n]*\s-d\b/, 'checkpoint tags may not be deleted'],
  [/\bgit\b[^|;&\n]*\bcommit\b[^|;&\n]*--amend\b/, '--amend rewrites a recorded checkpoint; make a new commit instead'],
];
const NEEDS_APPROVAL = /\bgit\s+(commit|push|reset|revert|rebase|merge|cherry-pick|tag|stash\s+drop|clean|checkout\s+--|restore)\b|cp\.js(?!\s+(status|sync|test|detect|profile\s+show|review\s+scope)\b)/;

// Quoted text (commit messages) is ignored when looking for bypass flags.
const unquote = (s) => s.replace(/"(?:[^"\\]|\\.)*"/g, '""').replace(/'[^']*'/g, "''");

function preBash() {
  const raw = String((input.tool_input || {}).command || '');
  const c = unquote(raw);
  const root = L.repoRoot(input.cwd || process.cwd());
  if (!L.isInstalled(root)) return;
  for (const [re, why] of BYPASS) if (re.test(c)) return deny(`${why}. This stays under the user's control; ask the user instead.`);
  if (/\bgit\s+push\b/.test(c)) {
    const br = L.branch(root);
    const explicit = c.match(/\bgit\s+push\s+(?:-\S+\s+)*\S+\s+(\S+)/);
    const target = explicit ? explicit[1].split(':').pop() : br;
    if (!L.FEATURE_BRANCH.test(target) || L.isProtected(target)) return deny(`pushes go only to ${L.CFG.branchPrefix}<name> branches (target: ${target}).`);
  }
  if (NEEDS_APPROVAL.test(c)) return ask('commits, pushes, rollbacks and checkpoint commands always need the user\'s approval.');
}

function postBash() {
  const c = String((input.tool_input || {}).command || '');
  const root = L.repoRoot(input.cwd || process.cwd());
  if (!L.isInstalled(root) || !/\bgit\s+push\b/.test(c)) return;
  require('child_process').spawnSync(process.execPath, [CP, 'sync'], { cwd: root, encoding: 'utf8' });
}

function summary(root, s) {
  const w = L.workingLines(root).total;
  const un = L.unpushed(root).length;
  const q = L.quarterOf(s);
  return `${s.feature.id} "${s.feature.name}" on ${s.feature.branch}, Q${q.n}/4 "${q.title}"; day: ${s.day ? s.day.date + (s.day.closed ? ' (closed)' : ' (open)') : 'none'}; uncommitted ${w}/${L.LIMIT} lines; ${un} unpushed commit(s); last good ${s.feature.lastGood || '—'}.`;
}

const K = require('./kitconf');

// A git repo Claude is working in, whether or not checkpoint-guard is on there yet.
function anyRepo() { return L.repoRoot(input.cwd || process.cwd()); }

function profileContext(root) {
  const P = require('./profile');
  const prof = P.load(root);
  const p = P.paths(root);
  if (!prof) {
    return `this repo has no project profile yet (repo id ${p.id}). Before any other work, run the project onboarding skill (/checkpoint-guard:project-onboarding): detect the stack and domain with node "${CP}" detect, ask the user the onboarding questions, show the profile for approval, then save it.`;
  }
  let text = `project profile ${p.id}: kind ${prof.kind}; stacks ${(prof.stacks || []).join(', ') || '?'}; lockfiles ${prof.lockfiles}; packages ${prof.packages.map((x) => `${x.path} (test: ${x.test})`).join('; ')}.`;
  if (prof.kind === 'team' && p.kitMd && fs.existsSync(p.kitMd)) {
    text += `\n--- team project notes (${p.kitMd}) ---\n${fs.readFileSync(p.kitMd, 'utf8').slice(0, 6000)}`;
  }
  return text;
}

function sessionStart() {
  const root = anyRepo();
  if (!root) return;
  const parts = [];
  parts.push(profileContext(root));
  if (!L.isInstalled(root)) {
    parts.push(`checkpoint-guard git hooks are not on in this repo. Run the doctor (node "${L.CFG.root ? L.norm(path.join(L.CFG.root, 'doctor.js')) : 'doctor.js'}"), and after the user's yes, --all.`);
    return context('SessionStart', parts.join('\n'));
  }
  require('child_process').spawnSync(process.execPath, [CP, 'sync'], { cwd: root, encoding: 'utf8' });
  const s = L.loadState(root);
  const t = L.now();
  if (!s.feature) parts.push(`no feature is active. When a task starts, propose a feature name and 4 quarter titles, get the user's approval, then run: node "${CP}" feature start "<name>" --quarters "t1|t2|t3|t4".`);
  else parts.push(`${summary(root, s)} Today is ${t.date} (${t.tz}). Before any work, ask the user: "Are we continuing the ${s.day ? s.day.date : '(none)'} day, or starting a new day?" Run node "${CP}" day new only after they confirm a new day.`);
  context('SessionStart', parts.join('\n'));
}

function prompt() {
  const root = anyRepo();
  if (!L.isInstalled(root)) return;
  const s = L.loadState(root);
  if (!s.feature) return;
  const t = L.now();
  const un = L.unpushed(root).length;
  const due = K.toMin(L.CFG.pushTime);
  if (t.hour * 60 + t.minute >= due - 30 && un > 0 && s.reminded !== t.date) {
    s.reminded = t.date;
    L.saveState(root, s);
    return context('UserPromptSubmit', `it is ${t.time} ${t.tz} and ${un} commit(s) are not pushed. The end-of-day push before ${L.CFG.pushTime} is mandatory: run the pre-push reviews (rule 3.9), tell the user, show the exact git push command for ${s.feature.branch}, and push only after they approve. Then ask whether to close the day (node "${CP}" day close --next "<where to pick up>").`);
  }
}

try {
  ({ 'pre-edit': preEdit, 'post-edit': postEdit, 'pre-bash': preBash, 'post-bash': postBash, 'session-start': sessionStart, prompt })[event]?.();
} catch { /* never break the session */ }
process.exit(0);
