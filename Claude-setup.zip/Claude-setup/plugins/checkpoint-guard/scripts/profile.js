'use strict';
// Project profile: everything stack- or domain-specific about one codebase, so the rest of the kit stays universal.
//   machine copy : <repo>/.git/checkpoint-guard/profile.json      (read by the gates)
//   kit copy     : <kit>/projects/<repo-id>/profile.json          (survives a re-clone; git-ignored in the kit)
//   readable     : team repo  -> <kit>/projects/<repo-id>/PROFILE.md (injected at session start)
//                  personal   -> "Project profile" section of the repo's own CLAUDE.md

const fs = require('fs');
const path = require('path');
const L = require('./lib');

function repoId(root) {
  const url = L.git(['config', '--get', 'remote.origin.url'], root).out;
  const base = url
    ? url.replace(/^[a-z]+:\/\//i, '').replace(/^[^@]+@/, '').replace(/\.git$/, '').replace(/[:/\\]+/g, '-')
    : path.basename(root);
  return L.slug(base, 80);
}

function paths(root) {
  const id = repoId(root);
  const kit = L.CFG.root;
  return {
    id,
    state: path.join(L.stateDir(root), 'profile.json'),
    kitJson: kit ? path.join(kit, 'projects', id, 'profile.json') : null,
    kitMd: kit ? path.join(kit, 'projects', id, 'PROFILE.md') : null,
  };
}

function load(root) {
  const p = paths(root);
  let prof = L.readJSON(p.state, null);
  if (!prof && p.kitJson) {
    prof = L.readJSON(p.kitJson, null);
    if (prof) L.writeJSON(p.state, prof);   // restored after a re-clone
  }
  return prof;
}

function validate(prof) {
  const e = [];
  if (!prof || typeof prof !== 'object') return ['profile is not a JSON object'];
  if (!['team', 'personal'].includes(prof.kind)) e.push('kind must be "team" or "personal"');
  if (!['never', 'commit'].includes(prof.lockfiles)) e.push('lockfiles must be "never" or "commit" (ask the user)');
  if (!Array.isArray(prof.packages) || !prof.packages.length) e.push('packages must list at least one package with its test command');
  for (const [i, pk] of (prof.packages || []).entries()) {
    if (typeof pk.path !== 'string') e.push(`packages[${i}].path missing (use "." for the repo root)`);
    if (!pk.test) e.push(`packages[${i}] (${pk.path}) has no test command; tests are required`);
  }
  if (prof.highImpact && !Array.isArray(prof.highImpact)) e.push('highImpact must be a list of path fragments');
  if (prof.related && typeof prof.related !== 'object') e.push('related must map a package path to a list of package paths');
  return e;
}

function save(root, prof) {
  const errs = validate(prof);
  if (errs.length) throw new Error('profile not saved:\n - ' + errs.join('\n - '));
  const p = paths(root);
  prof.repo = p.id;
  prof.updatedAt = L.stamp();
  L.writeJSON(p.state, prof);
  if (p.kitJson) L.writeJSON(p.kitJson, prof);
  return p;
}

// ---------- detection: a first draft for onboarding; Claude refines it with the user ----------

const SKIP = new Set(['.git', 'node_modules', 'dist', 'build', 'out', 'target', 'bin', 'obj', 'vendor', 'venv', '.venv', '__pycache__', 'coverage', 'docs', '.idea', '.vscode']);

function walk(root, depth = 0, acc = []) {
  if (depth > 5) return acc;
  let kids = [];
  try { kids = fs.readdirSync(root, { withFileTypes: true }); } catch { return acc; }
  acc.push({ dir: root, files: kids.filter((k) => k.isFile()).map((k) => k.name) });
  for (const k of kids) if (k.isDirectory() && !SKIP.has(k.name) && !k.name.startsWith('.')) walk(path.join(root, k.name), depth + 1, acc);
  return acc;
}

const has = (files, re) => files.some((f) => re.test(f));
const read = (f) => { try { return fs.readFileSync(f, 'utf8'); } catch { return ''; } };

function detectDir(dir, files) {
  const out = [];
  if (files.includes('package.json')) {
    const pj = L.readJSON(path.join(dir, 'package.json'), {});
    const sc = pj.scripts || {};
    const deps = { ...(pj.dependencies || {}), ...(pj.devDependencies || {}) };
    const pm = files.includes('pnpm-lock.yaml') ? 'pnpm' : files.includes('yarn.lock') ? 'yarn' : files.some((f) => /^bun\.lockb?$/.test(f)) ? 'bun' : 'npm';
    const fw = ['next', 'react', 'vue', '@angular/core', 'svelte', '@nestjs/core', 'express', 'fastify', 'electron'].filter((d) => deps[d]);
    out.push({ stack: 'node', frameworks: fw, test: sc.test && !/no test specified/.test(sc.test) ? `${pm} test` : null,
      lint: sc.lint ? `${pm} run lint` : null, e2e: sc['test:e2e'] ? `${pm} run test:e2e` : null, workspaces: !!pj.workspaces });
  }
  if (files.some((f) => ['pyproject.toml', 'setup.cfg', 'setup.py', 'requirements.txt', 'pytest.ini', 'tox.ini'].includes(f))) {
    const py = read(path.join(dir, 'pyproject.toml'));
    const fw = ['django', 'fastapi', 'flask'].filter((x) => new RegExp(x, 'i').test(py + read(path.join(dir, 'requirements.txt'))));
    out.push({ stack: 'python', frameworks: fw, test: 'python -m pytest -q', lint: /\[tool\.ruff/.test(py) ? 'ruff check .' : /flake8/.test(py + read(path.join(dir, 'setup.cfg'))) ? 'flake8' : null });
  }
  if (files.includes('go.mod')) out.push({ stack: 'go', test: 'go test ./...', lint: 'go vet ./...' });
  if (files.includes('pom.xml')) out.push({ stack: 'java-maven', test: 'mvn -q test', lint: null });
  if (has(files, /^build\.gradle(\.kts)?$/)) out.push({ stack: 'jvm-gradle', test: process.platform === 'win32' ? 'gradlew.bat test' : './gradlew test', lint: null });
  if (has(files, /\.(sln|csproj|fsproj)$/)) out.push({ stack: 'dotnet', test: 'dotnet test', lint: 'dotnet format --verify-no-changes' });
  if (files.includes('Cargo.toml')) out.push({ stack: 'rust', test: 'cargo test', lint: 'cargo clippy -- -D warnings' });
  if (files.includes('composer.json')) {
    const sc = (L.readJSON(path.join(dir, 'composer.json'), {}).scripts) || {};
    out.push({ stack: 'php', test: sc.test ? 'composer test' : 'vendor/bin/phpunit', lint: null });
  }
  if (files.includes('Gemfile')) out.push({ stack: 'ruby', test: fs.existsSync(path.join(dir, 'spec')) ? 'bundle exec rspec' : 'bundle exec rake test', lint: /rubocop/.test(read(path.join(dir, 'Gemfile'))) ? 'bundle exec rubocop' : null });
  if (files.includes('pubspec.yaml')) out.push({ stack: /flutter:/.test(read(path.join(dir, 'pubspec.yaml'))) ? 'flutter' : 'dart', test: /flutter:/.test(read(path.join(dir, 'pubspec.yaml'))) ? 'flutter test' : 'dart test', lint: 'dart analyze' });
  return out;
}

function detect(root) {
  const found = [];
  const ci = [];
  for (const { dir, files } of walk(root)) {
    for (const d of detectDir(dir, files)) found.push({ path: L.norm(path.relative(root, dir)) || '.', ...d });
  }
  for (const c of ['.github/workflows', '.gitlab-ci.yml', 'azure-pipelines.yml', 'Jenkinsfile', 'bitbucket-pipelines.yml', '.circleci']) {
    if (fs.existsSync(path.join(root, c))) ci.push(c);
  }
  const tracked = L.git(['ls-files'], root).out.split('\n');
  const RISKY = /(^|\/)(auth|security|secrets?|config|migrations?|payments?|billing|prompts?|permissions?|crypto)(\/|\.|$)/i;
  const highImpact = [...new Set(tracked.filter((f) => RISKY.test(f)).map((f) => {
    const m = f.match(/^(.*?(?:^|\/)(?:auth|security|secrets?|config|migrations?|payments?|billing|prompts?|permissions?|crypto))(?:\/|\.|$)/i);
    return m ? m[1] + '/' : null;
  }).filter(Boolean))].slice(0, 15);
  const stacks = [...new Set(found.map((f) => f.stack))];
  const readme = ['README.md', 'readme.md', 'README.rst', 'README'].map((f) => path.join(root, f)).find((f) => fs.existsSync(f));
  return {
    kind: '(ask: team or personal?)',
    lockfiles: '(ask: never or commit?)',
    stacks,
    frameworks: [...new Set(found.flatMap((f) => f.frameworks || []))],
    packages: found.map(({ path: p, stack, test, lint, e2e }) => ({ path: p, stack, test: test || '(ask: test command?)', lint: lint || null, e2e: e2e || null })),
    highImpact,
    related: {},
    ci,
    readme: readme ? L.norm(path.relative(root, readme)) : null,
    files: tracked.length,
  };
}

module.exports = { repoId, paths, load, save, validate, detect };
