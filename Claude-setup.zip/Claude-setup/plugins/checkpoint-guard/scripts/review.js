'use strict';
// checkpoint-guard: pre-push review gate (rule 3.9).
// scope  -> what is about to be pushed, limited to OUR non-merge commits (author = git user.email)
// record -> validates and stores the /code-review + /security-review report for exactly that HEAD

const fs = require('fs');
const path = require('path');
const L = require('./lib');
const B = require('./book');

const MAX_WORDS = 200;
const BLOCKING = /\b(critical|high)\b|🔴/i;

function pushRange(root) {
  const up = L.git(['rev-parse', '--abbrev-ref', '--symbolic-full-name', '@{u}'], root);
  return up.ok ? { args: ['@{u}..HEAD'], label: `${up.out}..HEAD` } : { args: ['HEAD', '--not', '--remotes'], label: 'HEAD (not on any remote yet)' };
}

function scope(root) {
  const range = pushRange(root);
  const me = L.git(['config', 'user.email'], root).out.toLowerCase();
  const all = L.git(['log', '--format=%H%x09%ae%x09%P%x09%s', ...range.args], root).out.split('\n').filter(Boolean).map((l) => {
    const [sha, email, parents, ...s] = l.split('\t');
    return { sha, email: email.toLowerCase(), merge: parents.trim().split(' ').length > 1, title: s.join('\t') };
  });
  const ours = all.filter((c) => !c.merge && c.email === me);
  const others = all.length - ours.length;
  const files = {};
  let added = 0, deleted = 0;
  for (const c of ours) {
    let file = null;
    for (const line of L.git(['show', '-U0', '--format=', c.sha], root).out.split('\n')) {
      const f = line.match(/^\+\+\+ b\/(.+)$/);
      if (f) { file = f[1]; if (!L.excluded(file)) files[file] = files[file] || []; continue; }
      if (line.startsWith('+++ /dev/null')) { file = null; continue; }
      const h = line.match(/^@@ -\d+(?:,\d+)? \+(\d+)(?:,(\d+))? @@/);
      if (h && file && files[file]) {
        const start = +h[1], n = h[2] === undefined ? 1 : +h[2];
        if (n > 0) files[file].push(n === 1 ? `${start}` : `${start}-${start + n - 1}`);
      }
    }
    const st = L.countNumstat(L.git(['show', '--numstat', '--format=', c.sha], root).out);
    st.files.forEach((x) => { added += x.added; deleted += x.deleted; });
  }
  for (const f of Object.keys(files)) {
    const spans = files[f].map((r) => r.split('-').map(Number)).map(([a, b]) => [a, b || a]).sort((x, y) => x[0] - y[0]);
    const merged = [];
    for (const [a, b] of spans) { const last = merged[merged.length - 1]; if (last && a <= last[1] + 1) last[1] = Math.max(last[1], b); else merged.push([a, b]); }
    files[f] = merged.map(([a, b]) => (a === b ? `${a}` : `${a}-${b}`));
  }
  const s = L.loadState(root);
  const cps = ours.map((c) => {
    const t = L.cpTagFor(root, c.sha);
    return t ? t.split('/').pop() : c.sha.slice(0, 7);
  }).reverse();
  return {
    head: L.git(['rev-parse', 'HEAD'], root).out, branch: L.branch(root), range: range.label, me,
    ours, others, files, added, deleted, cps, feature: s.feature ? s.feature.id : null,
  };
}

function printScope(sc) {
  const lines = [
    `Push of ${sc.branch} @ ${sc.head.slice(0, 7)} · range ${sc.range}`,
    `Our changes (author ${sc.me}, no merges): ${sc.ours.length} commit(s) ${sc.cps.join(', ')} · ${Object.keys(sc.files).length} file(s) · +${sc.added}/−${sc.deleted}`,
    `Excluded: ${sc.others} commit(s) by others or merges`,
    '',
    'Review ONLY these files and lines; drop findings anywhere else and count them as "Skipped":',
    ...Object.entries(sc.files).map(([f, r]) => `  ${f}  lines ${r.join(', ') || '(deleted only)'}`),
    '',
    'Then write the report (<= 200 words) with "## Code review", "## Security review", a "Skipped:" line',
    'and "Verdict: PASS" or "Verdict: FIX FIRST" (FIX FIRST if any critical/high finding), and run:',
    '  cp.js review record --file <path-to-report.md>',
  ];
  return lines.join('\n');
}

function words(text) {
  return text.replace(/[`*_#>|-]/g, ' ').split(/\s+/).filter((w) => /[\p{L}\p{N}]/u.test(w)).length;
}

function record(root, file) {
  if (!file || !fs.existsSync(file)) throw new Error('give --file <path to the report .md>');
  const sc = scope(root);
  if (!sc.ours.length) throw new Error('nothing of ours to push, so there is nothing to review.');
  const raw = fs.readFileSync(file, 'utf8').replace(/\r/g, '');
  const body = raw.replace(/^# .*\n+/, '').trim();
  const problems = [];
  if (!/^## Code review/im.test(body)) problems.push('missing "## Code review" section');
  if (!/^## Security review/im.test(body)) problems.push('missing "## Security review" section');
  const v = body.match(/^Verdict:\s*(PASS|FIX FIRST)\s*$/m);
  if (!v) problems.push('missing a final line "Verdict: PASS" or "Verdict: FIX FIRST"');
  const n = words(body);
  if (n > MAX_WORDS) problems.push(`report is ${n} words; keep it to ${MAX_WORDS} or fewer`);
  const findings = body.split('\n').filter((l) => /^\s*[-*]\s/.test(l) && !/^\s*[-*]\s*(none|no findings)/i.test(l));
  const blocking = findings.filter((l) => BLOCKING.test(l));
  if (v && v[1] === 'PASS' && blocking.length) problems.push(`${blocking.length} critical/high finding(s) listed but the verdict is PASS; it must be FIX FIRST`);
  if (problems.length) throw new Error('report not recorded:\n - ' + problems.join('\n - '));

  const s = L.loadState(root);
  s.reviews = s.reviews || [];
  s.reviewSeq = (s.reviewSeq || 0) + 1;
  const id = `RV-${L.pad(s.reviewSeq, 3)}`;
  const short = sc.head.slice(0, 7);
  const dir = s.feature && s.day ? path.join(L.dayDir(root, s), 'reviews') : path.join(L.cpRoot(root), 'reviews');
  const out = path.join(dir, `${id}_${short}.md`);
  B.write(out, [
    `# ${id} · ${sc.branch} @ ${short}`,
    '',
    `- **Recorded:** ${L.stamp()} · **Verdict:** ${v[1]}`,
    `- **Scope (our changes only):** ${sc.ours.length} commit(s) ${sc.cps.join(', ')} · ${Object.keys(sc.files).length} file(s) · +${sc.added}/−${sc.deleted} · ${sc.others} other commit(s) excluded`,
    `- **Range:** ${sc.range}`,
    '',
    body,
    '',
  ].join('\n'));
  s.reviews.push({ id, head: sc.head, verdict: v[1], file: B.rel(root, out), at: L.stamp(), feature: sc.feature });
  L.saveState(root, s);
  if (s.feature && s.day) B.appendDay(root, s, `- ${L.istNow().time} · [${id}](reviews/${path.basename(out)}) · pre-push review @ ${short} · ${v[1] === 'PASS' ? '✅ PASS' : '⛔ FIX FIRST'} (${findings.length} finding(s))`);
  return { id, verdict: v[1], file: out, findings: findings.length, blocking: blocking.length, words: n };
}

function passed(root, sha) {
  const s = L.loadState(root);
  return (s.reviews || []).some((r) => r.head === sha && r.verdict === 'PASS');
}

module.exports = { scope, printScope, record, passed };
