'use strict';
// checkpoint-guard shared helpers: git, line budget, state, naming, clock. Stack-agnostic:
// everything about a particular codebase comes from its project profile (profile.js).

const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const K = require('./kitconf');

const CFG = K.load();
const NUDGE = CFG.budget.nudge;   // "we hit N lines" suggestion
const LIMIT = CFG.budget.limit;   // commits above this are refused
const HARD = CFG.budget.hard;     // absolute ceiling, even with a user-approved exception

// Lockfiles of common ecosystems. Never counted toward the budget; committing them follows the profile.
const LOCKFILES = [
  /(^|\/)package-lock\.json$/, /(^|\/)npm-shrinkwrap\.json$/, /(^|\/)yarn\.lock$/, /(^|\/)pnpm-lock\.yaml$/, /(^|\/)bun\.lockb?$/,
  /(^|\/)poetry\.lock$/, /(^|\/)Pipfile\.lock$/, /(^|\/)uv\.lock$/, /(^|\/)Cargo\.lock$/, /(^|\/)go\.sum$/,
  /(^|\/)composer\.lock$/, /(^|\/)Gemfile\.lock$/, /(^|\/)pubspec\.lock$/, /(^|\/)packages\.lock\.json$/, /(^|\/)gradle\.lockfile$/,
];
// Not counted toward the line budget.
const EXCLUDE = [
  ...LOCKFILES,
  /(^|\/)(dist|build|out|target|bin|obj|node_modules|vendor|coverage|\.venv|venv|__pycache__)\//,
  /\.min\.(js|css)$/, /\.map$/, /(^|\/)docs\/checkpoints\//,
];

const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const FEATURE_BRANCH = new RegExp(`^${esc(CFG.branchPrefix)}.+`);
const PROTECTED = CFG.protectedBranches.map(K.globToRe);
const isProtected = (b) => PROTECTED.some((r) => r.test(b));

function git(args, cwd) {
  const r = cp.spawnSync('git', args, { cwd, encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 });
  return { ok: r.status === 0, out: (r.stdout || '').trim(), err: (r.stderr || '').trim() };
}

function repoRoot(cwd) {
  const r = git(['rev-parse', '--show-toplevel'], cwd || process.cwd());
  return r.ok ? path.resolve(r.out) : null;
}

function gitDir(root) { return path.resolve(git(['rev-parse', '--absolute-git-dir'], root).out); }

function stateDir(root) {
  const d = path.join(gitDir(root), 'checkpoint-guard');
  fs.mkdirSync(d, { recursive: true });
  return d;
}

function isInstalled(root) {
  return !!root && fs.existsSync(path.join(gitDir(root), 'checkpoint-guard', 'installed'));
}

function readJSON(f, d) { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return d; } }
function writeJSON(f, o) { fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, JSON.stringify(o, null, 2)); }

function loadState(root) {
  const s = readJSON(path.join(stateDir(root), 'state.json'), {});
  s.config = { lint: CFG.lint, timeoutMin: CFG.testTimeoutMin, ...(s.config || {}) };
  return s;
}
function saveState(root, s) { writeJSON(path.join(stateDir(root), 'state.json'), s); }

const norm = (f) => String(f).replace(/\\/g, '/');
const excluded = (f) => EXCLUDE.some((r) => r.test(norm(f)));
const isLockfile = (f) => LOCKFILES.some((r) => r.test(norm(f)));

function countNumstat(text) {
  let total = 0;
  const files = [];
  for (const line of String(text).split('\n')) {
    if (!line.trim()) continue;
    const [a, d, ...rest] = line.split('\t');
    const file = rest.join('\t');
    if (a === '-' || excluded(file)) continue;
    const added = +a || 0, deleted = +d || 0;
    total += added + deleted;
    files.push({ file, added, deleted });
  }
  return { total, files };
}

function hasHead(root) { return git(['rev-parse', '--verify', 'HEAD'], root).ok; }
function stagedLines(root) { return countNumstat(git(['diff', '--cached', '--numstat'], root).out); }

function workingLines(root) {
  const base = countNumstat(git(hasHead(root) ? ['diff', 'HEAD', '--numstat'] : ['diff', '--cached', '--numstat'], root).out);
  const untracked = git(['ls-files', '--others', '--exclude-standard'], root).out.split('\n').filter(Boolean);
  for (const f of untracked) {
    if (excluded(f)) continue;
    try {
      const buf = fs.readFileSync(path.join(root, f));
      if (buf.includes(0)) continue;
      const n = buf.toString('utf8').split('\n').length;
      base.total += n;
      base.files.push({ file: f, added: n, deleted: 0 });
    } catch {}
  }
  return base;
}

function slug(s, max = 60) {
  return String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, max).replace(/-+$/, '') || 'untitled';
}
const pad = (n, w) => String(n).padStart(w, '0');

const now = () => K.now(CFG);
const istNow = now;   // kept for older callers
const stamp = () => { const t = now(); return `${t.date} ${t.time} ${t.tz}`; };

function branch(root) { return git(['rev-parse', '--abbrev-ref', 'HEAD'], root).out; }

const cpRoot = (root) => path.join(root, 'docs', 'checkpoints');
const featureDir = (root, s) => path.join(cpRoot(root), s.feature.folder);
const quarterOf = (s) => s.feature.quarters[s.feature.currentQuarter - 1];
const quarterDir = (root, s) => path.join(featureDir(root, s), quarterOf(s).folder);
const dayDir = (root, s) => path.join(quarterDir(root, s), s.day.date);

function unpushed(root) {
  if (!hasHead(root)) return [];
  const up = git(['rev-parse', '--abbrev-ref', '--symbolic-full-name', '@{u}'], root);
  return git(up.ok ? ['rev-list', '@{u}..HEAD'] : ['rev-list', 'HEAD', '--not', '--remotes'], root).out.split('\n').filter(Boolean);
}

function cpTagFor(root, sha) {
  return git(['tag', '--points-at', sha, '--list', 'cp/*'], root).out.split('\n').filter(Boolean)[0] || null;
}

module.exports = {
  CFG, NUDGE, LIMIT, HARD, EXCLUDE, LOCKFILES, FEATURE_BRANCH, isProtected,
  git, repoRoot, gitDir, stateDir, isInstalled, readJSON, writeJSON, loadState, saveState,
  norm, excluded, isLockfile, countNumstat, hasHead, stagedLines, workingLines, slug, pad, now, istNow, stamp,
  branch, cpRoot, featureDir, quarterOf, quarterDir, dayDir, unpushed, cpTagFor,
};
