'use strict';
// checkpoint-guard: writes the local checkpoint book under <repo>\docs\checkpoints.

const fs = require('fs');
const path = require('path');
const L = require('./lib');

const write = (f, text) => { fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, text); };
const rel = (root, f) => L.norm(path.relative(L.cpRoot(root), f));

function rollbackHelp(cpEntry, sha) {
  return [
    '```',
    `# 1. Record the rollback and the user's evidence:`,
    `node cp.js rollback prepare --to ${cpEntry.id} --method revert --evidence "<what broke>"`,
    `# 2a. Safe, keeps history (use for anything already pushed), one revert commit:`,
    `git revert --no-commit ${sha}..HEAD && git commit -m "Revert to ${cpEntry.id}: <reason>"`,
    `# 2b. Local only, discards later commits (explicit approval; prepare with --method reset):`,
    `git reset --hard ${cpEntry.tag}  &&  node cp.js rollback confirm`,
    '```',
  ].join('\n');
}

function writeCheckpoint(root, s, e) {
  const dir = L.dayDir(root, s);
  const file = path.join(dir, e.fileName);
  const tests = e.tests.length
    ? e.tests.map((t) => `  - ${t.ok ? '✅' : '❌'} \`${t.pkg}\` · \`${t.cmd}\` · ${t.summary}`).join('\n')
    : '  - (no code packages touched)';
  write(file, [
    `# ${e.id} · ${e.title}`,
    '',
    `- **Type:** ${e.type}`,
    `- **Timestamp:** ${e.timestamp}`,
    `- **Commit:** \`${e.sha}\` · **Tag:** \`${e.tag}\``,
    `- **Branch:** \`${e.branch}\``,
    `- **Feature:** ${s.feature.id} ${s.feature.name}`,
    `- **Quarter:** Q${s.feature.currentQuarter} of 4 · ${L.quarterOf(s).title}`,
    `- **Day:** ${s.day.date}`,
    `- **Lines:** +${e.added} / −${e.deleted} = ${e.lines} (limit ${L.LIMIT}${e.exception ? `, approved exception up to ${e.exception.limit}: ${e.exception.reason}` : ''})`,
    `- **Tests:** ${e.testsOk ? 'passed' : 'FAILED'}${e.evidence ? ` · evidence: [${path.basename(e.evidence)}](evidence/${path.basename(e.evidence)})` : ''}`,
    tests,
    `- **Pushed:** no`,
    e.rollback ? `- **Rolled back to:** ${e.rollback.to} via \`${e.rollback.method}\` · user evidence: ${e.rollback.evidence || 'pasted in chat'}` : null,
    '',
    '## What changed',
    '',
    e.body ? e.body : '_(no commit description)_',
    '',
    '## Files',
    '',
    ...e.files.map((f) => `- \`${f.file}\` +${f.added} −${f.deleted}`),
    '',
    '## Roll back to this checkpoint',
    '',
    rollbackHelp(e, e.sha),
    '',
  ].filter((x) => x !== null).join('\n'));
  return file;
}

function writeQuarter(root, s, q) {
  const f = s.feature;
  const cps = f.checkpoints.filter((c) => c.quarter === q.n);
  write(path.join(L.featureDir(root, s), q.folder, 'QUARTER.md'), [
    `# Q${q.n} · ${q.title}`,
    '',
    `- **Feature:** ${f.id} ${f.name}`,
    `- **Status:** ${q.status}${q.pushedAt ? ` · pushed ${q.pushedAt}` : ''}`,
    `- **Lines:** ${cps.reduce((a, c) => a + c.lines, 0)} across ${cps.length} checkpoint(s)`,
    '',
    '| CP | Title | Day | Lines | Tests | Pushed |',
    '|---|---|---|---|---|---|',
    ...cps.map((c) => `| [${c.id}](${L.norm(path.relative(path.join(L.featureDir(root, s), q.folder), path.join(L.cpRoot(root), c.file)))}) | ${c.title} | ${c.date} | ${c.lines} | ${c.testsOk ? '✅' : '❌'} | ${c.pushed ? '✅' : '—'} |`),
    '',
  ].join('\n'));
}

function writeFeature(root, s) {
  const f = s.feature;
  f.quarters.forEach((q) => writeQuarter(root, s, q));
  write(path.join(L.featureDir(root, s), 'FEATURE.md'), [
    `# ${f.id} · ${f.name}`,
    '',
    `- **Branch:** \`${f.branch}\``,
    `- **Started:** ${f.startedAt}`,
    `- **Base commit (roll back whole feature):** \`${f.base}\``,
    `- **Status:** ${f.status} · current quarter Q${f.currentQuarter}`,
    `- **Last known good:** ${f.lastGood || '—'}`,
    '',
    '## Plan',
    '',
    '| Quarter | Title | Status | Checkpoints | Pushed |',
    '|---|---|---|---|---|',
    ...f.quarters.map((q) => {
      const n = f.checkpoints.filter((c) => c.quarter === q.n).length;
      return `| [Q${q.n}](${q.folder}/QUARTER.md) | ${q.title} | ${q.status} | ${n} | ${q.pushedAt || '—'} |`;
    }),
    '',
    '## Roll back the whole feature',
    '',
    '```',
    `git revert --no-commit ${f.base}..HEAD && git commit -m "Revert ${f.id}: <reason>"   # safe`,
    `git reset --hard ${f.base}   # local only, with explicit approval`,
    '```',
    '',
  ].join('\n'));
  writeIndex(root, s);
}

function writeIndex(root, s) {
  const list = s.features || [];
  write(path.join(L.cpRoot(root), 'INDEX.md'), [
    '# Checkpoints',
    '',
    'Local only: this folder is listed in `.git/info/exclude` and never committed.',
    '',
    '| # | Feature | Branch | Status | Last known good |',
    '|---|---|---|---|---|',
    ...list.map((x) => `| ${x.id} | [${x.name}](${x.folder}/FEATURE.md) | \`${x.branch}\` | ${x.status} | ${x.lastGood || '—'} |`),
    '',
  ].join('\n'));
}

function dayFile(root, s) { return path.join(L.dayDir(root, s), 'DAY.md'); }

function ensureDay(root, s) {
  const f = dayFile(root, s);
  if (!fs.existsSync(f)) {
    write(f, [`# ${s.day.date} · ${s.feature.id} · Q${s.feature.currentQuarter}`, '', `Opened ${s.day.openedAt}`, '', '## Checkpoints', ''].join('\n'));
  }
  return f;
}

function appendDay(root, s, line) {
  const f = ensureDay(root, s);
  fs.appendFileSync(f, line + '\n');
}

function syncRegistry(s) {
  if (!s.feature) return;
  s.features = s.features || [];
  const i = s.features.findIndex((x) => x.id === s.feature.id);
  const row = { id: s.feature.id, name: s.feature.name, folder: s.feature.folder, branch: s.feature.branch, status: s.feature.status, lastGood: s.feature.lastGood };
  if (i < 0) s.features.push(row); else s.features[i] = row;
}

module.exports = { writeCheckpoint, writeQuarter, writeFeature, writeIndex, ensureDay, appendDay, dayFile, syncRegistry, rel, write };
