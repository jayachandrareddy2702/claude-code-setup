#!/usr/bin/env node
'use strict';
// checkpoint-guard CLI. Run inside a repo:  node <kit>/plugins/checkpoint-guard/scripts/cp.js <command>
//
//   install                              add the git hooks to this repo (asks nothing, changes nothing else)
//   feature start "<name>" --quarters "t1|t2|t3|t4"     user-approved name and quarter titles
//   feature close
//   day new                              start a new working day (only after the user confirms)
//   day close [--next "<where to pick up>"]
//   quarter next                         move to the next quarter (current one must be pushed)
//   test                                 run the commit gate's suites on what is staged now
//   allow-oversize <441-480> "<reason>"  user-approved, single-use, edge/critical cases only
//   rollback prepare --to CP-006 --method revert|reset [--evidence <file>]
//   rollback confirm                     log a completed reset as a checkpoint entry
//   detect                               draft a project profile from the codebase (read-only)
//   profile show                         print this repo's saved profile
//   profile set --file <profile.json>    save the user-approved profile (gates read it)
//   profile notes --file <notes.md>      team repos: save the readable notes to the kit (injected each session)
//   review scope                         our commits/files/lines about to be pushed (rule 3.9)
//   review record --file <report.md>     store the <=200-word /code-review + /security-review report
//   config lint on|off | config timeout <minutes>
//   status | sync | repair

const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const L = require('./lib');
const B = require('./book');
const T = require('./tests');
const R = require('./review');
const P = require('./profile');

const args = process.argv.slice(2);
const [cmd, sub] = args;
const opt = (name) => { const i = args.indexOf(name); return i >= 0 ? args[i + 1] : undefined; };
const die = (msg) => { process.stderr.write(`checkpoint-guard: ${msg}\n`); process.exit(1); };
const say = (msg) => process.stdout.write(msg + '\n');

const root = L.repoRoot(process.cwd());
if (!root) die('not inside a git repository.');

function need(cond, msg) { if (!cond) die(msg); }
function load() { return L.loadState(root); }

function install() {
  const hooksPath = L.git(['config', '--get', 'core.hooksPath'], root).out;
  need(!hooksPath, `core.hooksPath is set to "${hooksPath}" (husky or similar). Not overwriting it; tell the user.`);
  const dir = path.join(L.gitDir(root), 'hooks');
  fs.mkdirSync(dir, { recursive: true });
  const script = L.norm(path.join(__dirname, 'githook.js'));
  for (const h of ['pre-commit', 'commit-msg', 'post-commit', 'pre-push']) {
    const f = path.join(dir, h);
    if (fs.existsSync(f) && !fs.readFileSync(f, 'utf8').includes('checkpoint-guard')) {
      fs.copyFileSync(f, f + '.before-checkpoint-guard');
      say(`kept your existing ${h} hook as ${h}.before-checkpoint-guard`);
    }
    const kit = L.CFG.root ? L.norm(L.CFG.root) : '';
    fs.writeFileSync(f, `#!/bin/sh\n# checkpoint-guard (claude-kit)\n${kit ? `export CLAUDE_KIT="${kit}"\n` : ''}exec node "${script}" ${h} "$@"\n`, { mode: 0o755 });
  }
  const ex = path.join(L.gitDir(root), 'info', 'exclude');
  fs.mkdirSync(path.dirname(ex), { recursive: true });
  const cur = fs.existsSync(ex) ? fs.readFileSync(ex, 'utf8') : '';
  if (!cur.includes('docs/checkpoints/')) fs.appendFileSync(ex, `${cur.endsWith('\n') || !cur ? '' : '\n'}# checkpoint-guard: local checkpoint book\ndocs/checkpoints/\n`);
  fs.writeFileSync(path.join(L.stateDir(root), 'installed'), L.stamp());
  const s = load(); L.saveState(root, s);
  say(`installed in ${root}\n  hooks: pre-commit, commit-msg, post-commit, pre-push\n  docs/checkpoints/ is local only (.git/info/exclude)`);
}

function featureStart() {
  const name = args[2];
  const qs = (opt('--quarters') || '').split('|').map((x) => x.trim()).filter(Boolean);
  need(name && !name.startsWith('--'), 'give the feature name: feature start "<name>" --quarters "t1|t2|t3|t4"');
  need(qs.length === 4, 'give exactly 4 user-approved quarter titles: --quarters "t1|t2|t3|t4"');
  const br = L.branch(root);
  need(L.FEATURE_BRANCH.test(br), `switch to a ${L.CFG.branchPrefix}<name> branch first (current: ${br}).`);
  const s = load();
  need(!s.feature || s.feature.status !== 'active', `feature ${s.feature && s.feature.id} is still active; run feature close first.`);
  s.featureSeq = (s.featureSeq || 0) + 1;
  const id = `F${L.pad(s.featureSeq, 3)}`;
  s.feature = {
    id, name, folder: `${id}-${L.slug(name)}`, branch: br, status: 'active', startedAt: L.stamp(),
    base: L.hasHead(root) ? L.git(['rev-parse', '--short', 'HEAD'], root).out : '(no commits yet)',
    currentQuarter: 1, nextCp: 1, lastGood: null, checkpoints: [],
    quarters: qs.map((t, i) => ({ n: i + 1, title: t, folder: `Q${i + 1}-${L.slug(t, 40)}`, status: i === 0 ? 'active' : 'planned', pushedAt: null })),
  };
  s.day = null;
  B.syncRegistry(s);
  L.saveState(root, s);
  B.writeFeature(root, s);
  say(`${id} "${name}" started on ${br}\n  base commit ${s.feature.base}\n  ${B.rel(root, L.featureDir(root, s))}\nNext: confirm the day with the user, then: day new`);
}

function featureClose() {
  const s = load();
  need(s.feature && s.feature.status === 'active', 'no active feature.');
  sync(s, true);
  const open = s.feature.checkpoints.filter((c) => !c.pushed).length;
  need(open === 0, `${open} checkpoint(s) are not pushed yet. Push them (with approval) before closing the feature.`);
  s.feature.status = 'done';
  s.feature.quarters.forEach((q) => { if (q.status !== 'done') q.status = 'done'; });
  B.syncRegistry(s); B.writeFeature(root, s);
  s.feature = null; s.day = null;
  L.saveState(root, s);
  say('feature closed.');
}

function dayNew() {
  const s = load();
  need(s.feature && s.feature.status === 'active', 'start a feature first.');
  const t = L.istNow();
  need(!(s.day && !s.day.closed && s.day.date === t.date), `the ${t.date} day is already open.`);
  if (s.day && !s.day.closed) dayCloseInner(s, null);
  s.day = { date: t.date, openedAt: L.stamp(), closed: false };
  L.saveState(root, s);
  B.ensureDay(root, s);
  say(`day ${t.date} opened in Q${s.feature.currentQuarter}: ${B.rel(root, L.dayDir(root, s))}`);
}

function dayCloseInner(s, next) {
  sync(s, true);
  const cps = s.feature.checkpoints.filter((c) => c.date === s.day.date);
  const wl = L.workingLines(root).total;
  const notPushed = cps.filter((c) => !c.pushed).length;
  B.appendDay(root, s, [
    '', `## Closed ${L.stamp()}`, '',
    `- Checkpoints today: ${cps.length} (${cps.map((c) => c.id).join(', ') || '—'})`,
    `- Pushed: ${cps.length - notPushed} of ${cps.length}${notPushed ? ' ⚠️ push the rest' : ''}`,
    `- Uncommitted at close: ${wl} lines${wl ? ' (carry-over, not a checkpoint)' : ''}`,
    `- Start here next: ${next || '—'}`, '',
  ].join('\n'));
  s.day.closed = true;
}

function dayClose() {
  const s = load();
  need(s.day && !s.day.closed, 'no open day.');
  dayCloseInner(s, opt('--next'));
  L.saveState(root, s);
  say(`day ${s.day.date} closed.`);
}

function quarterNext() {
  const s = load();
  need(s.feature && s.feature.status === 'active', 'no active feature.');
  sync(s, true);
  const q = L.quarterOf(s);
  const mine = s.feature.checkpoints.filter((c) => c.quarter === q.n);
  need(mine.length > 0, `Q${q.n} has no checkpoints yet.`);
  need(mine.every((c) => c.pushed), `Q${q.n} has unpushed checkpoints. Each quarter ends with a push (with approval).`);
  need(q.n < 4, 'this is the last quarter; use feature close.');
  q.status = 'done'; q.pushedAt = q.pushedAt || L.stamp();
  s.feature.currentQuarter += 1;
  L.quarterOf(s).status = 'active';
  L.saveState(root, s);
  if (s.day && !s.day.closed) B.ensureDay(root, s);
  B.writeFeature(root, s);
  say(`now in Q${s.feature.currentQuarter}: ${L.quarterOf(s).title}`);
}

function test() {
  const s = load();
  const r = T.run(root, s);
  if (r.problems.length) die('blocked:\n - ' + r.problems.join('\n - '));
  r.results.forEach((x) => say(`${x.ok ? 'PASS' : 'FAIL'}  ${x.pkg} · ${x.cmd} · ${x.summary}`));
  if (!r.results.length) say('no code packages in the staged change.');
  if (!r.ok) die('tests failed; do not commit.');
  say('all required suites passed for the staged tree.');
}

function allowOversize() {
  const n = parseInt(args[1], 10);
  const reason = args[2];
  need(n > L.LIMIT && n <= L.HARD, `give a limit between ${L.LIMIT + 1} and ${L.HARD}.`);
  need(reason, 'give the reason (edge/critical case).');
  const s = load();
  s.oversize = { limit: n, reason, approvedAt: L.stamp(), used: false };
  L.saveState(root, s);
  say(`one commit may change up to ${n} lines: ${reason}`);
}

function rollback() {
  const s = load();
  need(s.feature, 'no active feature.');
  if (sub === 'prepare') {
    const to = opt('--to'), method = opt('--method');
    need(/^CP-\d{3}$/.test(to || ''), 'give --to CP-###');
    need(['revert', 'reset'].includes(method), 'give --method revert or reset');
    const c = s.feature.checkpoints.find((x) => x.id === to);
    need(c, `${to} not found in ${s.feature.id}.`);
    const ev = opt('--evidence');
    s.pendingRollback = { to, method, evidence: ev || null, sha: c.sha, preparedAt: L.stamp() };
    L.saveState(root, s);
    if (method === 'revert') say(`run (with user approval):\n  git revert --no-commit ${c.sha}..HEAD && git commit -m "Revert to ${to}: <reason>"`);
    else say(`run (with user approval, local only, discards later commits):\n  git reset --hard ${c.tag}\nthen: node cp.js rollback confirm`);
  } else if (sub === 'confirm') {
    const rb = s.pendingRollback;
    need(rb && rb.method === 'reset', 'no prepared reset.');
    need(L.git(['rev-parse', 'HEAD'], root).out === rb.sha, 'HEAD is not at the prepared checkpoint yet.');
    const id = `CP-${L.pad(s.feature.nextCp, 3)}`;
    const file = path.join(L.dayDir(root, s), `${id}_rollback-to-${L.slug(rb.to)}.md`);
    B.write(file, `# ${id} · Rollback to ${rb.to}\n\n- **Type:** rollback (reset)\n- **Timestamp:** ${L.stamp()}\n- **Now at:** \`${rb.sha.slice(0, 7)}\` (${rb.to})\n- **User evidence:** ${rb.evidence || 'pasted in chat'}\n- **Commits after ${rb.to} were discarded locally.**\n`);
    const cut = s.feature.checkpoints.findIndex((c) => c.id === rb.to);
    s.feature.checkpoints.slice(cut + 1).forEach((c) => { c.rolledBack = true; });
    s.feature.lastGood = `${rb.to} (${rb.sha.slice(0, 7)})`;
    s.feature.nextCp += 1;
    s.pendingRollback = null;
    B.syncRegistry(s); L.saveState(root, s);
    B.appendDay(root, s, `- ${L.istNow().time} · ${id} · rollback to ${rb.to} (reset)`);
    B.writeFeature(root, s);
    say(`${id} recorded.`);
  } else die('rollback prepare|confirm');
}

// Mark checkpoints pushed when their commit is on a remote branch.
function sync(s, quiet) {
  s = s || load();
  if (!s.feature) return s;
  let changed = 0;
  for (const c of s.feature.checkpoints) {
    if (c.pushed || c.rolledBack) continue;
    if (L.git(['branch', '-r', '--contains', c.sha], root).out) {
      c.pushed = true; changed++;
      const f = path.join(L.cpRoot(root), c.file);
      try { fs.writeFileSync(f, fs.readFileSync(f, 'utf8').replace('- **Pushed:** no', `- **Pushed:** yes · ${L.stamp()}`)); } catch {}
    }
  }
  if (changed) {
    const q = L.quarterOf(s);
    if (s.feature.checkpoints.filter((c) => c.quarter === q.n).every((c) => c.pushed)) q.pushedAt = L.stamp();
    L.saveState(root, s); B.writeFeature(root, s);
  }
  if (!quiet) say(`${changed} checkpoint(s) newly marked as pushed.`);
  return s;
}

function status() {
  const s = sync(load(), true);
  const wl = L.workingLines(root).total;
  const un = L.unpushed(root).length;
  if (!s.feature) { say(`no active feature · uncommitted ${wl} lines`); return; }
  const q = L.quarterOf(s);
  say([
    `${s.feature.id} ${s.feature.name} · ${s.feature.branch}`,
    `Q${q.n}/4 ${q.title}`,
    `day: ${s.day ? s.day.date + (s.day.closed ? ' (closed)' : ' (open)') : 'none open'}`,
    `uncommitted: ${wl}/${L.LIMIT} lines${wl >= L.NUDGE ? ' ⚠️ commit a checkpoint before going ahead' : ''}`,
    `unpushed commits: ${un}`,
    `checkpoints: ${s.feature.checkpoints.length} · last good: ${s.feature.lastGood || '—'}`,
  ].join('\n'));
}

function config() {
  const s = load();
  if (sub === 'lint') s.config.lint = args[2] === 'on';
  else if (sub === 'timeout') { const m = parseInt(args[2], 10); need(m > 0, 'minutes?'); s.config.timeoutMin = m; }
  else die('config lint on|off | config timeout <minutes>');
  L.saveState(root, s);
  say(`lint gate: ${s.config.lint ? 'on' : 'off'} · time limit: ${s.config.timeoutMin} min`);
}

function repair() {
  if (L.cpTagFor(root, 'HEAD')) { say('HEAD already has a checkpoint.'); return; }
  cp.spawnSync(process.execPath, [path.join(__dirname, 'githook.js'), 'post-commit'], { cwd: root, stdio: 'inherit' });
}

try {
  if (cmd === 'install') install();
  else if (cmd === 'feature' && sub === 'start') featureStart();
  else if (cmd === 'feature' && sub === 'close') featureClose();
  else if (cmd === 'day' && sub === 'new') dayNew();
  else if (cmd === 'day' && sub === 'close') dayClose();
  else if (cmd === 'quarter' && sub === 'next') quarterNext();
  else if (cmd === 'test') test();
  else if (cmd === 'allow-oversize') allowOversize();
  else if (cmd === 'rollback') rollback();
  else if (cmd === 'detect') say(JSON.stringify(P.detect(root), null, 2));
  else if (cmd === 'profile' && sub === 'show') { const pr = P.load(root); say(pr ? JSON.stringify(pr, null, 2) : `no profile for ${P.repoId(root)} yet`); }
  else if (cmd === 'profile' && sub === 'set') {
    const f = opt('--file'); need(f && fs.existsSync(f), 'give --file <profile.json>');
    let pr; try { pr = JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { die(`not valid JSON: ${e.message}`); }
    const p = P.save(root, pr);
    say(`profile saved for ${p.id} (${pr.kind})\n  ${p.state}${p.kitJson ? `\n  ${p.kitJson}` : ''}`);
    if (pr.kind === 'team') say('Team repo: write the readable notes with  profile notes --file <notes.md>  (kept in the kit, not in the repo).');
    else say('Personal repo: add the readable "Project profile" section to this repo\'s CLAUDE.md.');
  }
  else if (cmd === 'profile' && sub === 'notes') {
    const f = opt('--file'); need(f && fs.existsSync(f), 'give --file <notes.md>');
    const p = P.paths(root); need(p.kitMd, 'kit folder not found (CLAUDE_KIT).');
    B.write(p.kitMd, fs.readFileSync(f, 'utf8'));
    say(`team notes saved: ${p.kitMd}`);
  }
  else if (cmd === 'review' && sub === 'scope') say(R.printScope(R.scope(root)));
  else if (cmd === 'review' && sub === 'record') {
    const r = R.record(root, opt('--file'));
    say(`${r.id} recorded · ${r.verdict} · ${r.findings} finding(s), ${r.blocking} blocking · ${r.words} words\n  ${B.rel(root, r.file)}`);
    if (r.verdict !== 'PASS') say('Push stays blocked: fix the critical/high findings (new checkpoint), then review again.');
  }
  else if (cmd === 'config') config();
  else if (cmd === 'sync') sync(null, false);
  else if (cmd === 'status') status();
  else if (cmd === 'repair') repair();
  else die('commands: install · feature start|close · day new|close · quarter next · test · allow-oversize · rollback prepare|confirm · detect · profile show|set|notes · review scope|record · config · status · sync · repair');
} catch (e) { die(e.message); }
