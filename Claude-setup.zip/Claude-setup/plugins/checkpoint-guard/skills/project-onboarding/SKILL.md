---
name: project-onboarding
description: Onboard a codebase of any stack or domain before the first change. Use automatically on the first session in a repo that has no project profile (the session-start message says so), or when the user asks to onboard, re-onboard or update the project profile.
---

# Project Onboarding

Goal: understand this codebase well enough that the universal rules (global CLAUDE.md) can be applied
to it, and record everything stack- or domain-specific in its **project profile**. Read-only until the
user approves; works in plan mode.

`cp.js` = `node "<kit>/plugins/checkpoint-guard/scripts/cp.js"` (the kit path is in the global CLAUDE.md).

## 1. Detect (read-only)

1. Run `cp.js detect`. It drafts stacks, frameworks, packages with test/lint/e2e commands, CI files,
   the README and likely high-impact paths.
2. Read, briefly: the README, the main manifest(s), the CI config, the top-level folder layout and one
   or two representative source and test files.
3. Work out:
   - **Stack**: languages, frameworks, package manager, build tool, test runner, linter/formatter
   - **Shape**: single package or monorepo; which packages talk to each other
   - **Domain**: what the product does, who uses it, data it handles (PII, payments, health …)
   - **Risk**: auth, secrets/config, migrations, payments, prompts, public APIs, generated code
   - **Conventions**: naming, folder structure, error handling, logging, commit style already in use
   - **How to run checks**: verify each detected command exists (scripts, Makefile, CI steps). Don't run
     long or server-starting commands (rule 3.6)

## 2. Ask the user (one round, with your suggestions)

Ask everything in one message (or one multiple-choice round), each question with your suggested answer:

1. Is this a **team** repo or a **personal** one? (team → notes kept in the kit; personal → in this repo's CLAUDE.md)
2. **Lockfiles**: never commit, or commit? (suggest from the ecosystem: apps in Go/Rust/Flutter usually commit)
3. For each package: the **test**, **lint**, **e2e** and **build** commands (show what you detected)
4. **High-impact paths** that widen the test run, and **related** packages to test together
5. **Do-not-touch** areas and domain rules (e.g. "all SQL parameterised", "no PII in logs")
6. New files must ship with a test? (default yes)
7. Anything else stack-specific: environment setup, services needed for tests, generated code to ignore

## 3. Show for approval

Show both, and save nothing before a clear yes:

**profile.json** (machine-readable; the gates use it)
```json
{
  "kind": "team",
  "lockfiles": "never",
  "stacks": ["node", "python"],
  "frameworks": ["express", "fastapi"],
  "packages": [
    { "path": "services/api", "test": "npm test", "lint": "npm run lint", "e2e": "npm run test:e2e" },
    { "path": "web", "test": "npm test", "lint": "npm run lint" }
  ],
  "highImpact": ["services/api/src/auth/", "services/api/src/config/"],
  "related": { "services/api": ["web"] },
  "newFileNeedsTest": true
}
```

**Readable notes** (short; for Claude in every session)
```markdown
# <Project> — project profile
Stack · Domain · Packages and how they connect · Test/lint/e2e commands
High-impact paths · Do not modify without deep review · Domain rules · Conventions
```

## 4. Save (after the yes; each command asks the user's approval)

1. Write the JSON to a temp file, then `cp.js profile set --file <temp>/profile.json`
2. Readable notes:
   - **team**: write to a temp file, then `cp.js profile notes --file <temp>/notes.md` (kept in the kit, injected every session; never written into the team's repo)
   - **personal**: add or update a `## Project profile` section in the repo's own `CLAUDE.md`
3. Run the doctor with `--all` (after the user's yes) so the checkpoint hooks are on in this repo
4. Confirm in one line what was saved and where

## Updating later

When the stack, commands or risky areas change, run this skill again. It's a rule change, so
confirm twice (rule 1.2) and show the before and after.
