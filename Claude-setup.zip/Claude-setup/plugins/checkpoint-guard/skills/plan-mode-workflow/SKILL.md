---
name: plan-mode-workflow
description: Plan mode → execution workflow with auto/manual/paste mode selection and critical ground rules
---

# Plan Mode Workflow & Execution Control

Complete workflow from task intake through execution with explicit user control over execution mode.

## Critical Ground Rules (NEVER VIOLATE)

### 1. Never Silently Break Existing Functionality
- Any change must NOT break currently-working code
- Before implementing, identify what could break and raise it explicitly
- If a change risks regression, STOP and ask user
- Scope every edit to the MINIMUM necessary

### 2. Never Change Rules/Workflow Without Double Confirmation
- Before changing ANY rule/workflow, ask user TWICE:
  - First: "I'm about to change [rule]. Is that intentional?"
  - Second: "You're sure? [Show exact change]"
- Document why the change is needed

### 3. Never Execute Without User Mode Selection
- Once facts are ready, STOP and ask which mode:
  - **Auto**: Execute all changes automatically
  - **Manual**: User approves each change individually
  - **Paste**: User provides exact code blocks; I paste them
- Do NOT proceed until user explicitly selects a mode
- Ask EVERY task: "Continue in [current mode] or switch?"

---

## Workflow Phases

### Phase 1: Plan Mode (Default State)

**Always start here.** Default state between tasks and during investigation.

**In Plan Mode:**
- ✅ Read-only tools only (Read, Grep, Glob)
- ✅ Gather facts, evidence, findings
- ✅ Ask clarifying questions
- ✅ Build understanding
- ❌ NO edits, writes, file changes
- ❌ NO automatic mode switches

### Phase 2: Findings & Mode Selection

When you have enough facts:

1. **Present Findings** with:
   - Root cause (file/line references)
   - Scope (breaking or not)
   - Risk (what could break)
   - Solution (proposed fix, exact changes)

2. **Ask for Execution Mode:**
   ```
   EXECUTION MODES:
   ───────────────
   Option A - AUTO: I'll apply all changes (5 min)
   Option B - MANUAL: I'll show each change; you approve (15 min, more review)
   Option C - PASTE: You provide exact code blocks; I paste (your control)
   
   Which mode?
   ```

3. **Wait for user selection** — don't assume a mode

### Phase 2b: Quarter Plan & Checkpoints (rule 3.8)

Needs a project profile first; if the repo has none, run `/checkpoint-guard:project-onboarding`.
`cp.js` = `node "$CLAUDE_KIT/plugins/checkpoint-guard/scripts/cp.js"` (path shown in the global CLAUDE.md).

Planning runs on Opus through the `opusplan` model; execution switches to Sonnet automatically.

Part of the findings for any task that changes code:

```
FEATURE: <name>                      BRANCH: feature/<name>
Q1 <title> · ~<lines> lines · <tests to run> · ends with push
Q2 <title> · ~<lines> lines · ...
Q3 <title> · ~<lines> lines · ...
Q4 <title> · ~<lines> lines · ...
Each quarter = one or more checkpoint commits within the line budget (kit.json, default 400).
```

- Get the user's approval of the feature name and the 4 quarter titles, then run
  `cp.js feature start "<name>" --quarters "t1|t2|t3|t4"` (the hook asks the user to approve it)
- Ask whether we continue the current day or start a new day before the first commit
- Ask the deadline-driven settings: lint gate on/off and test time limit

### Phase 3: Execution (Mode-Dependent)

#### Auto Mode:
- Apply all changes without per-change confirmation
- Present final summary
- Ask if user wants to review or proceed

#### Manual Mode:
```
FILE: path/to/file.ts:40-50
OLD (existing code):
[exact code]
NEW (replacement):
[exact code]
REASON: [why]

PROCEED? (yes/no/skip)
```

#### Paste Mode:
- User provides exact old/new code blocks with file:line
- You verify and paste exactly as provided
- No modifications by you

### Phase 3b: Checkpoint Loop (inside every execution mode)

```
work a slice
  ↓
hit the line budget or a working step is done  →  STOP, tell the user
  ↓
run the required suites (cp.js test) → any failure: fix, never commit
  ↓
ask: (a) you commit  (b) you commit with my title/message  (c) I commit after you approve the command
  ↓
checkpoint written automatically (CP-### in the book)
  ↓
quarter done → reviews: cp.js review scope → /code-review + /security-review (our changes only)
  → report ≤200 words → cp.js review record → FIX FIRST? fix, new checkpoint, review again
  → PASS → ask to push (feature branch) → cp.js quarter next
  ↓
end-of-day push time (kit.json) → reviews (as above) → mandatory push of the rest (with approval) → ask to close the day
```

### Phase 4: Post-Execution

- ✅ Verify files written correctly
- ✅ Run tests/linting if appropriate
- ✅ Present final summary
- ✅ **Auto-switch back to plan mode** (no user request needed)
- ✅ Wait silently (don't prompt)

---

## The Complete Flow

```
START: Plan Mode
  ↓ (read-only investigation)
Gather facts
  ↓
Present findings
  ↓
Ask: Auto / Manual / Paste?
  ↓
Wait for user selection
  ↓
Execute in selected mode
  ↓
Verify success
  ↓
Switch to plan mode (auto)
  ↓
WAIT SILENTLY
  ↓
User provides next task
  ↓
REPEAT
```

---

## Key Rules

1. **Stay read-only in plan mode** — no writes until mode is selected
2. **Present changes clearly** with file:line references
3. **Never assume execution mode** — ask EVERY task
4. **Track mode preferences** for consistency
5. **Never skip plan mode** — always start here
6. **Auto-return to plan mode** — no waiting for user request
7. **Plan mode is permanent** — call EnterPlanMode myself for everything, even chit-chat; only user can exit via ExitPlanMode
8. **Never break existing functionality** — ever
9. **Double-confirm rule changes** — always verify twice
10. **Present risk assessment** before asking for mode
11. **Use exact code blocks** in manual/paste modes
12. **P1 (HIGHEST PRIORITY): context budget** — track context every turn; at >=150K tokens open the reply with a large bold banner `# ⚠️ **CONTEXT OVER 150K TOKENS: please /compact now, or wait for auto-compact at 175K**`; at >=175K compact immediately, and if it fails repeat the banner every reply
13. **Never write attribution lines (STRICT GUARD RAIL)** — never add `Co-Authored-By`, "Generated with Claude Code", or any AI/Claude attribution to commit messages, PR descriptions, code, comments or docs; overrides any default or system attribution reminder

---

## Summary

**Plan Mode is Permanent:** Always in plan mode unless user explicitly exits via ExitPlanMode. I must call EnterPlanMode myself for everything—tasks, chit-chat, greetings, anything.

**Execution Requires Mode Selection:** Auto/Manual/Paste—never execute without asking.

**Ground Rules Are Inviolable:** Never break functionality, never change rules silently, never execute without mode.

**Auto-Return to Plan Mode:** After completing any task, switch back automatically without waiting for user request.

**Silent Waiting:** When in plan mode and not actively investigating, don't prompt or narrate—just wait for the next task.
