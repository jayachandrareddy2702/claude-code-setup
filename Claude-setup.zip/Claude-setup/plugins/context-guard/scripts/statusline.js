#!/usr/bin/env node
// context-guard status line: live context counter with warn/cut colours.
'use strict';

const fs = require('fs');
const path = require('path');

const WARN = num(process.env.CONTEXT_GUARD_WARN, 150000);
const CUT = num(process.env.CONTEXT_GUARD_CUT, 175000);

function num(v, d) {
  const n = parseInt(v, 10);
  return Number.isFinite(n) && n > 0 ? n : d;
}

let data = {};
try { data = JSON.parse(fs.readFileSync(0, 'utf8') || '{}'); } catch {}

const cw = data.context_window || {};
const size = cw.context_window_size || 200000;
const u = cw.current_usage;
let used = u
  ? (u.input_tokens || 0) + (u.cache_creation_input_tokens || 0) + (u.cache_read_input_tokens || 0)
  : Math.round(((cw.used_percentage || 0) / 100) * size);

const pct = Math.round((used / size) * 100);
const green = '\x1b[32m', yellow = '\x1b[33m', red = '\x1b[31m', dim = '\x1b[2m', reset = '\x1b[0m';
const colour = used >= CUT ? red : used >= WARN ? yellow : green;
const filled = Math.min(10, Math.round(pct / 10));
const bar = '▓'.repeat(filled) + '░'.repeat(10 - filled);

let hint = `compact at ${Math.round(CUT / 1000)}K`;
if (used >= CUT) hint = 'run /compact before your next message';
else if (used >= WARN) hint = `${Math.round((CUT - used) / 1000)}K left before /compact`;

const model = (data.model && data.model.display_name) || '';
const dir = data.workspace && data.workspace.current_dir ? path.basename(data.workspace.current_dir) : '';

// checkpoint-guard line budget, when that plugin is installed in this repo.
let delta = '';
try {
  const CG = require(path.join(__dirname, '..', '..', 'checkpoint-guard', 'scripts', 'lib.js'));
  const root = CG.repoRoot(data.workspace && data.workspace.current_dir);
  if (CG.isInstalled(root)) {
    const w = CG.workingLines(root).total;
    const c = w >= CG.LIMIT ? red : w >= CG.NUDGE ? yellow : green;
    delta = `  ${c}Δ ${w}/${CG.LIMIT}${reset}${w >= CG.NUDGE ? ` ${dim}commit a checkpoint${reset}` : ''}`;
  }
} catch {}

process.stdout.write(
  `${dim}${model}${dir ? ' · ' + dir : ''}${reset}  ${colour}ctx ${bar} ${Math.round(used / 1000)}K/${Math.round(size / 1000)}K ${pct}%${reset} ${dim}${hint}${reset}${delta}`
);
