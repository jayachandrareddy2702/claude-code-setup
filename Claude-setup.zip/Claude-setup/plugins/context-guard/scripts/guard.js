#!/usr/bin/env node
// context-guard: measured context counter + turn-boundary compaction gate.
// Usage (from hooks.json): node guard.js <prompt|stop|precompact|postcompact>
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');

const WARN = num(process.env.CONTEXT_GUARD_WARN, 150000);
const CUT = num(process.env.CONTEXT_GUARD_CUT, 175000);
const EMERGENCY = num(process.env.CONTEXT_GUARD_EMERGENCY, 190000);
const TAIL_BYTES = 4 * 1024 * 1024;

const BANNER =
  '# ⚠️ **CONTEXT OVER 150K TOKENS: please /compact after this reply. New messages are held at 175K until you do**';

function num(v, d) {
  const n = parseInt(v, 10);
  return Number.isFinite(n) && n > 0 ? n : d;
}

function k(n) {
  return Math.round(n / 1000) + 'K';
}

function readStdin() {
  try {
    return JSON.parse(fs.readFileSync(0, 'utf8') || '{}');
  } catch {
    return {};
  }
}

function stateFile(sessionId) {
  const dir = path.join(os.tmpdir(), 'context-guard');
  try { fs.mkdirSync(dir, { recursive: true }); } catch {}
  const id = String(sessionId || 'default').replace(/[^\w.-]/g, '_');
  return path.join(dir, id + '.json');
}

function loadState(file) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return { busy: false, tokens: 0 }; }
}

function saveState(file, state) {
  try { fs.writeFileSync(file, JSON.stringify({ ...state, updatedAt: Date.now() })); } catch {}
}

// Tokens currently in context = input + cache writes + cache reads of the
// latest main-thread API response (same formula as the status line's used_percentage).
// A compact boundary after the latest response means the context was just reset.
function measure(transcriptPath) {
  if (!transcriptPath) return null;
  let text;
  try {
    const stat = fs.statSync(transcriptPath);
    const start = Math.max(0, stat.size - TAIL_BYTES);
    const fd = fs.openSync(transcriptPath, 'r');
    const buf = Buffer.alloc(stat.size - start);
    fs.readSync(fd, buf, 0, buf.length, start);
    fs.closeSync(fd);
    text = buf.toString('utf8');
  } catch {
    return null;
  }
  const lines = text.split('\n');
  for (let i = lines.length - 1; i >= 0; i--) {
    const line = lines[i].trim();
    if (!line) continue;
    let entry;
    try { entry = JSON.parse(line); } catch { continue; }
    if (entry.type === 'system' && entry.subtype === 'compact_boundary') return 0;
    if (entry.isSidechain) continue;
    const u = entry.message && entry.message.usage;
    if (entry.type === 'assistant' && u) {
      return (u.input_tokens || 0) + (u.cache_creation_input_tokens || 0) + (u.cache_read_input_tokens || 0);
    }
  }
  return null;
}

function out(obj) {
  process.stdout.write(JSON.stringify(obj));
}

function main() {
  const event = process.argv[2];
  const input = readStdin();
  const file = stateFile(input.session_id);
  const state = loadState(file);
  const measured = measure(input.transcript_path);
  const tokens = measured === null ? state.tokens || 0 : measured;

  switch (event) {
    case 'prompt': {
      const prompt = String(input.prompt || '').trim().toLowerCase();
      if (prompt.startsWith('/compact') || prompt.startsWith('/clear')) {
        saveState(file, { busy: false, tokens });
        return;
      }
      if (tokens >= CUT) {
        saveState(file, { busy: false, tokens });
        out({
          decision: 'block',
          reason: `Context is at ${k(tokens)} tokens (limit ${k(CUT)}). Run /compact, then send your message again.`,
        });
        return;
      }
      saveState(file, { busy: true, tokens });
      if (tokens >= WARN) {
        out({
          hookSpecificOutput: {
            hookEventName: 'UserPromptSubmit',
            additionalContext:
              `context-guard measured ${tokens} tokens in context (warn ${WARN}, cut ${CUT}). ` +
              `Per rule 3.3, open your reply with this banner exactly:\n${BANNER}`,
          },
        });
      }
      return;
    }
    case 'stop': {
      saveState(file, { busy: false, tokens });
      return;
    }
    case 'precompact': {
      const trigger = input.trigger || 'auto';
      if (trigger === 'auto' && state.busy && tokens < EMERGENCY) {
        out({
          decision: 'block',
          reason: `context-guard: turn in progress at ${k(tokens)} tokens; compaction waits until the turn ends (emergency limit ${k(EMERGENCY)}).`,
        });
        return;
      }
      return;
    }
    case 'postcompact': {
      saveState(file, { busy: state.busy, tokens: 0 });
      return;
    }
    default:
      return;
  }
}

try { main(); } catch { /* never break a session */ }
process.exit(0);
