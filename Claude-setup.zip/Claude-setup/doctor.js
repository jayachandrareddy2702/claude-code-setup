#!/usr/bin/env node
'use strict';
// claude-kit doctor — daily health check and repair, on any OS.
//   node <kit>/doctor.js          full check on the first run of the day, quick check after
//   node <kit>/doctor.js --full   always the full check
//   node <kit>/doctor.js --all    fix everything it can (run only after the user's yes), then check again
// Checks: kit settings, global CLAUDE.md, tools, Claude CLI, marketplace + plugins (installed, enabled,
// current), old project-tools leftovers, settings (CLAUDE_KIT, status line, model), every folder and repo
// in the workspace roots (local-scope plugins, git hooks, project profiles), Headroom, scheduled reminder
// and backup, backup freshness, skills, kit on GitHub, and a self-test of the hooks.

const fs = require('fs');
const os = require('os');
const path = require('path');
const cp = require('child_process');
const T = require('./tools/kitlib');

const argv = process.argv.slice(2);
const FIX = argv.includes('--all') || argv.includes('--fix');
const FULL = argv.includes('--full') || FIX;
const STAMP = path.join(os.tmpdir(), 'claude-kit-doctor', 'last-run.json');
const CPJS = path.join(T.KIT, 'plugins', 'checkpoint-guard', 'scripts', 'cp.js');
const rel = (f) => T.fwd(f);

const results = [];
const add = (status, name, detail, fix) => results.push({ status, name, detail, fix });

// ---------- checks ----------

function checkKit(cfg) {
  if (!fs.existsSync(T.cfgFile)) return add('fail', 'Kit settings', `kit.json missing: run the installer (${T.WIN ? 'install.cmd' : './install.sh'})`, null);
  add(cfg.workspaceRoots.length ? 'ok' : 'warn', 'Kit settings', cfg.workspaceRoots.length ? `kit ${T.version()} · roots: ${cfg.workspaceRoots.join(', ')}` : 'no workspace roots set: run the installer', null);
}

function checkGlobalMd(cfg) {
  const st = T.globalMdState(cfg);
  const msg = { ok: 'current for this machine', stale: 'older than the kit copy or kit.json', missing: 'missing', foreign: 'a CLAUDE.md not from the kit is in place' }[st];
  add(st === 'ok' ? 'ok' : st === 'foreign' ? 'warn' : 'fail', 'Global CLAUDE.md', `~/.claude/CLAUDE.md ${msg}`, st === 'ok' || st === 'foreign' ? null : 'globalmd');
}

function checkTools() {
  const n = T.run('node', ['-v']); const g = T.run('git', ['--version']);
  add(n.ok && g.ok ? 'ok' : 'fail', 'Node and Git', `${n.ok ? 'node ' + n.out : 'node not found'} · ${g.ok ? g.out : 'git not found'}`, null);
  if (T.WIN) {
    const bash = ['C:\\Program Files\\Git\\bin\\bash.exe', 'C:\\Program Files (x86)\\Git\\bin\\bash.exe'].find((p) => fs.existsSync(p));
    if (!bash) return add('warn', 'Node in Git Bash', 'Git Bash not found; git hooks need node on its PATH', null);
    const r = T.run(bash, ['-lc', 'node -v'], { shell: false });
    add(r.ok ? 'ok' : 'fail', 'Node in Git Bash', r.ok ? `node ${r.out}` : 'git hooks cannot find node: add Node to the PATH', null);
  }
}

function parsePluginList(text) {
  const map = {}; let cur = null;
  for (const line of String(text).split('\n')) {
    const id = line.match(/([\w.-]+)@([\w.-]+)/);
    if (id && !/^\s*(Version|Scope|Status)\b/i.test(line)) { cur = `${id[1]}@${id[2]}`; map[cur] = map[cur] || {}; }
    if (!cur) continue;
    const v = line.match(/Version:\s*(\S+)/i); if (v) map[cur].version = v[1];
    const s = line.match(/Status:\s*(.+)$/i); if (s) map[cur].status = s[1].trim().toLowerCase();
  }
  return map;
}

function checkPlugins(full) {
  const st = T.readJSON(T.SETTINGS) || {};
  const en = st.enabledPlugins || {};
  if (!full) {
    for (const p of T.PLUGINS) add(en[`${p}@${T.MARKET}`] === true ? 'ok' : 'fail', `Plugin ${p}`, en[`${p}@${T.MARKET}`] === true ? 'enabled (quick check)' : 'not enabled', 'install');
    return;
  }
  const cli = T.run('claude', ['--version']);
  if (!cli.ok) return add('fail', 'Claude Code CLI', '`claude` is not on PATH: install Claude Code (https://code.claude.com/docs/en/setup)', null);
  const ml = T.run('claude', ['plugin', 'marketplace', 'list']).out;
  add(ml.includes(T.MARKET) ? 'ok' : 'fail', `Marketplace ${T.MARKET}`, ml.includes(T.MARKET) ? 'registered' : 'not registered', 'marketplace');
  if (ml.includes(T.LEGACY_MARKET)) add('fail', 'Old setup', `marketplace "${T.LEGACY_MARKET}" (C:\\project\\claude-plugins) still registered; its hooks would run twice`, 'legacy');
  const list = parsePluginList(T.run('claude', ['plugin', 'list']).out);
  for (const p of T.PLUGINS) {
    const id = `${p}@${T.MARKET}`, e = list[id], want = T.pluginVersion(p);
    if (!e) { add('fail', `Plugin ${p}`, 'not installed', 'install'); continue; }
    if ((e.status && /disabled|off/.test(e.status)) || en[id] === false) { add('fail', `Plugin ${p}`, `installed ${e.version || ''} but disabled`, 'enable'); continue; }
    if (want && e.version && e.version !== want) { add('warn', `Plugin ${p}`, `installed ${e.version}, kit has ${want}`, 'update'); continue; }
    add('ok', `Plugin ${p}`, `installed ${e.version || ''} · enabled`, null);
  }
}

function checkSettings(cfg) {
  const st = T.readJSON(T.SETTINGS);
  if (!st) return add('fail', 'Claude settings', '~/.claude/settings.json missing or not valid JSON', fs.existsSync(T.SETTINGS) ? null : 'settings');
  const issues = [];
  if (!st.env || T.fwd(st.env.CLAUDE_KIT || '') !== T.fwd(T.KIT)) issues.push('CLAUDE_KIT');
  if (st.model !== cfg.model) issues.push(`model (${st.model || 'unset'} → ${cfg.model})`);
  const sl = st.statusLine && st.statusLine.command;
  const ours = sl && /context-guard[\\/]+scripts[\\/]+statusline\.js/.test(sl);
  if (!sl || (ours && !sl.includes(T.fwd(T.KIT)))) issues.push('status line');
  if (sl && !ours) add('warn', 'Status line', `your own status line is set (${sl}); not replacing it`, null);
  add(issues.length ? 'fail' : 'ok', 'Claude settings', issues.length ? `needs: ${issues.join(', ')}` : 'CLAUDE_KIT, model and status line set', issues.length ? 'settings' : null);
}

function repoStatus(root) {
  const gd = path.resolve(T.run('git', ['rev-parse', '--absolute-git-dir'], { cwd: root, shell: false }).out || path.join(root, '.git'));
  const hp = T.run('git', ['config', '--get', 'core.hooksPath'], { cwd: root, shell: false }).out;
  if (hp) return { state: 'husky', detail: hp, gd };
  const kitPath = T.fwd(T.KIT);
  const bad = ['pre-commit', 'commit-msg', 'post-commit', 'pre-push'].filter((h) => { try { const t = fs.readFileSync(path.join(gd, 'hooks', h), 'utf8'); return !t.includes('checkpoint-guard') || !t.includes(kitPath); } catch { return true; } });
  return bad.length || !fs.existsSync(path.join(gd, 'checkpoint-guard', 'installed')) ? { state: 'missing', gd } : { state: 'ok', gd };
}

const localFile = (folder) => path.join(folder, '.claude', 'settings.local.json');
const localMissing = (folder) => { const ep = (T.readJSON(localFile(folder)) || {}).enabledPlugins || {}; return T.PLUGINS.filter((p) => ep[`${p}@${T.MARKET}`] !== true); };
const localLegacy = (folder) => Object.keys((T.readJSON(localFile(folder)) || {}).enabledPlugins || {}).filter((k) => k.endsWith(`@${T.LEGACY_MARKET}`));

function hasProfile(repo, gd) {
  if (fs.existsSync(path.join(gd, 'checkpoint-guard', 'profile.json'))) return true;
  const P = require(path.join(T.KIT, 'plugins', 'checkpoint-guard', 'scripts', 'profile.js'));
  try { return !!P.load(repo); } catch { return false; }
}

function checkCoverage(cfg) {
  const { folders, repos } = T.discover(cfg);
  if (!folders.length) return add('warn', 'Coverage', 'no folders found in the workspace roots', null);
  const noLocal = folders.filter((f) => localMissing(f).length);
  const legacy = folders.filter((f) => localLegacy(f).length);
  add(noLocal.length ? 'fail' : 'ok', 'Folders (local scope)', noLocal.length ? `${folders.length - noLocal.length}/${folders.length} have both plugins; missing: ${noLocal.map(rel).join(', ')}` : `all ${folders.length} folders have both plugins`, noLocal.length ? { folders: noLocal } : null);
  if (legacy.length) add('fail', 'Old local entries', `${legacy.length} folder(s) still enable ${T.LEGACY_MARKET} plugins`, { legacyFolders: legacy });
  const st = repos.map((r) => ({ r, ...repoStatus(r) }));
  const miss = st.filter((x) => x.state === 'missing'), husky = st.filter((x) => x.state === 'husky');
  add(miss.length ? 'fail' : husky.length ? 'warn' : 'ok', 'Repos (git hooks)', [`${st.filter((x) => x.state === 'ok').length}/${repos.length} on (pointing at this kit)`, miss.length ? `missing or old: ${miss.map((x) => rel(x.r)).join(', ')}` : '', husky.length ? `skipped (core.hooksPath): ${husky.map((x) => rel(x.r)).join(', ')}` : ''].filter(Boolean).join('; '), miss.length ? { repos: miss.map((x) => x.r) } : null);
  const noProf = st.filter((x) => x.state !== 'husky' && !hasProfile(x.r, x.gd));
  add(noProf.length ? 'warn' : 'ok', 'Project profiles', noProf.length ? `${noProf.length} repo(s) not onboarded yet: ${noProf.map((x) => rel(x.r)).join(', ')}. Onboarding runs when you open Claude there` : `all ${st.length} repos have a profile`, null);
}

function checkHeadroom(cfg) {
  const { folders } = T.discover(cfg);
  const hf = [...cfg.workspaceRoots, ...folders].filter((f) => fs.existsSync(path.join(f, '.claude', '.headroom_wrap_owners.json')));
  const installed = T.run('headroom', ['--version']).ok;
  if (cfg.headroom || installed) {
    const st = T.headroomState();
    const miss = [!st.uv && 'uv', !st.py && 'Python 3.13', !st.headroom && 'Headroom'].filter(Boolean);
    if (miss.length) add('fail', 'Headroom setup', `missing: ${miss.join(', ')} (HEADROOM.md steps 2-4)`, 'headroom');
    else add(st.doctorOk ? 'ok' : 'warn', 'Headroom setup', `${st.uvVer} · Python 3.13 · ${st.headroom}${st.doctorOk ? ' · doctor ok' : ' · `headroom doctor` reports a problem (HEADROOM.md troubleshooting)'}`, null);
  }
  if (!hf.length) { if (!cfg.headroom && !installed) add('info', 'Headroom', 'not used on this machine; to add it, run the installer again or follow HEADROOM.md', null); return; }
  const bad = [];
  for (const f of hf) {
    const owners = T.readJSON(path.join(f, '.claude', '.headroom_wrap_owners.json')) || {};
    const s = T.readJSON(localFile(f));
    const p = [];
    if (!s) p.push('settings.local.json unreadable');
    else {
      for (const [k, v] of Object.entries(owners)) if (v && v.original !== undefined && (s.env || {})[k] !== v.original) p.push(`env ${k}`);
      if (!JSON.stringify(s.hooks || {}).includes('headroom')) p.push('self-heal hook missing');
    }
    if (p.length) bad.push(`${rel(f)}: ${p.join(', ')}`);
  }
  add(bad.length ? 'warn' : 'ok', 'Headroom', bad.length ? `${bad.join('; ')}. Not changed by the doctor; start Claude there so Headroom self-heals` : `${hf.length} folder(s) managed by Headroom; intact`, null);
}

function checkTasks(cfg) {
  add(T.scheduled('remind') ? 'ok' : 'fail', 'Push reminder', T.scheduled('remind') ? `scheduled ${cfg.reminderTime} (${cfg.reminderDays.join(',')})` : 'not scheduled', 'remind');
  add(T.scheduled('backup') ? 'ok' : 'fail', 'Backup task', T.scheduled('backup') ? `daily at ${cfg.backup.time}` : 'not scheduled', 'backuptask');
  let last = null; try { last = fs.readFileSync(path.join(T.KIT, 'backup', 'LATEST'), 'utf8').trim(); } catch {}
  const age = last ? (Date.parse(T.today()) - Date.parse(last)) / 86400000 : Infinity;
  add(age <= 1 ? 'ok' : 'warn', 'Kit backup', last ? `latest ${last}` : 'no backup yet', age <= 1 ? null : 'backupnow');
}

function checkSkills() {
  const miss = ['plan-mode-workflow', 'project-onboarding'].filter((s) => !fs.existsSync(path.join(T.KIT, 'plugins', 'checkpoint-guard', 'skills', s, 'SKILL.md')));
  add(miss.length ? 'fail' : 'ok', 'Skills', miss.length ? `missing in the kit: ${miss.join(', ')}` : '/checkpoint-guard:plan-mode-workflow, /checkpoint-guard:project-onboarding', null);
}

function checkGitHub() {
  if (!fs.existsSync(path.join(T.KIT, '.git'))) return add('warn', 'Kit on GitHub', 'the kit is not a git repo yet; see "Keep the kit on GitHub" in setup-guide.html', null);
  const url = T.run('git', ['config', '--get', 'remote.origin.url'], { cwd: T.KIT, shell: false }).out;
  const dirty = T.run('git', ['status', '--porcelain'], { cwd: T.KIT, shell: false }).out;
  add(url ? (dirty ? 'warn' : 'ok') : 'warn', 'Kit on GitHub', url ? `${url}${dirty ? ' · uncommitted kit changes: commit and push them' : ''}` : 'no remote set', null);
}

function selfTest() {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'kit-doctor-'));
  const node = process.execPath, problems = [];
  // a throwaway kit marker, so the test uses default settings and never writes into the real kit's projects/
  const fakeKit = path.join(tmp, 'kit');
  fs.mkdirSync(path.join(fakeKit, '.claude-plugin'), { recursive: true });
  fs.writeFileSync(path.join(fakeKit, '.claude-plugin', 'marketplace.json'), JSON.stringify({ name: 'claude-kit', plugins: [] }));
  const env = { ...process.env, CLAUDE_KIT: fakeKit };
  try {
    const tr = path.join(tmp, 't.jsonl');
    const at = (n) => fs.writeFileSync(tr, JSON.stringify({ type: 'assistant', message: { usage: { input_tokens: 0, cache_creation_input_tokens: 0, cache_read_input_tokens: n } } }) + '\n');
    const guard = path.join(T.KIT, 'plugins', 'context-guard', 'scripts', 'guard.js');
    const g = (inp) => cp.spawnSync(node, [guard, 'prompt'], { input: JSON.stringify(inp), encoding: 'utf8', env: { ...env, TMP: tmp, TEMP: tmp, TMPDIR: tmp } }).stdout || '';
    at(160000); if (!/CONTEXT OVER 150K/.test(g({ session_id: 'd1', transcript_path: tr, prompt: 'x' }))) problems.push('150K banner');
    at(180000); if (!/"decision":"block"/.test(g({ session_id: 'd2', transcript_path: tr, prompt: 'x' }))) problems.push('175K hold');

    const repo = path.join(tmp, 'repo'); fs.mkdirSync(path.join(repo, 'app'), { recursive: true });
    const git = (...a) => cp.spawnSync('git', a, { cwd: repo, encoding: 'utf8', env });
    git('init', '-q'); git('config', 'user.email', 'doctor@local'); git('config', 'user.name', 'doctor');
    git('commit', '-q', '--allow-empty', '-m', 'init');
    const prefix = 'feature/';
    git('switch', '-q', '-c', `${prefix}doctor`);
    const c = (...a) => cp.spawnSync(node, [CPJS, ...a], { cwd: repo, encoding: 'utf8', env });
    c('install');
    const pf = path.join(tmp, 'profile.json');
    fs.writeFileSync(pf, JSON.stringify({ kind: 'personal', lockfiles: 'never', packages: [{ path: 'app', test: 'node -e "process.exit(1)"' }] }));
    c('profile', 'set', '--file', pf); c('feature', 'start', 'Doctor', '--quarters', 'a|b|c|d'); c('day', 'new');
    const hook = path.join(T.KIT, 'plugins', 'checkpoint-guard', 'scripts', 'claude-hook.js');
    const pre = cp.spawnSync(node, [hook, 'pre-bash'], { input: JSON.stringify({ cwd: repo, tool_input: { command: 'git commit --no-verify -m x' } }), encoding: 'utf8', env }).stdout || '';
    if (!/"permissionDecision":"deny"/.test(pre)) problems.push('--no-verify deny');
    fs.writeFileSync(path.join(repo, 'app', 'x.txt'), 'x\n'); git('add', '-A');
    if (git('commit', '-q', '-m', 'feat: x').status === 0) problems.push('test gate (failing suite committed)');
    fs.writeFileSync(pf, JSON.stringify({ kind: 'personal', lockfiles: 'never', packages: [{ path: 'app', test: 'node -e "process.exit(0)"' }] }));
    c('profile', 'set', '--file', pf);
    if (git('commit', '-q', '-m', 'feat: x').status !== 0) problems.push('commit gate (passing commit refused)');
    cp.spawnSync('git', ['init', '-q', '--bare', path.join(tmp, 'remote.git')], { encoding: 'utf8' });
    git('remote', 'add', 'origin', path.join(tmp, 'remote.git'));
    if (git('push', '-q', 'origin', `${prefix}doctor`).status === 0) problems.push('review gate (pushed without review)');
  } catch (e) { problems.push(`crashed: ${e.message}`); }
  finally {
    try { fs.rmSync(tmp, { recursive: true, force: true }); } catch {}
  }
  add(problems.length ? 'fail' : 'ok', 'Hooks self-test', problems.length ? `not working: ${problems.join('; ')}` : 'banner, hold, --no-verify deny, test gate and review gate behave', problems.length ? 'update' : null);
}

// ---------- fixes ----------

function fixAll(cfg) {
  const done = [];
  const kinds = new Set(results.filter((r) => r.status === 'fail' || r.status === 'warn').map((r) => (typeof r.fix === 'string' ? r.fix : null)).filter(Boolean));
  const step = (label, cmd, args, opts) => { const r = T.run(cmd, args, opts); done.push(`${r.ok ? '✅' : '❌'} ${label}${r.ok ? '' : ': ' + r.out.split('\n').slice(-1)[0]}`); return r.ok; };
  const tryDo = (label, fn) => { try { fn(); done.push(`✅ ${label}`); } catch (e) { done.push(`❌ ${label}: ${e.message}`); } };

  if (kinds.has('legacy')) step(`remove old marketplace ${T.LEGACY_MARKET}`, 'claude', ['plugin', 'marketplace', 'remove', T.LEGACY_MARKET]);
  if (kinds.has('marketplace')) step('add marketplace claude-kit', 'claude', ['plugin', 'marketplace', 'add', T.KIT]);
  if (kinds.has('install') || kinds.has('update') || kinds.has('enable')) step('refresh marketplace', 'claude', ['plugin', 'marketplace', 'update', T.MARKET]);
  for (const r of results.filter((x) => x.name.startsWith('Plugin '))) {
    const p = r.name.slice(7), id = `${p}@${T.MARKET}`;
    if (r.fix === 'install') step(`install ${p}`, 'claude', ['plugin', 'install', id, '--scope', 'user']);
    if (r.fix === 'enable') step(`enable ${p}`, 'claude', ['plugin', 'enable', id]);
    if (r.fix === 'update') step(`update ${p}`, 'claude', ['plugin', 'update', id]);
  }
  if (kinds.has('update') && !results.some((x) => x.name.startsWith('Plugin ') && x.fix === 'update')) for (const p of T.PLUGINS) step(`update ${p}`, 'claude', ['plugin', 'update', `${p}@${T.MARKET}`]);
  if (kinds.has('globalmd')) tryDo('global CLAUDE.md written for this machine', () => T.writeGlobalMd(cfg));
  if (kinds.has('settings')) tryDo('Claude settings (CLAUDE_KIT, model, status line)', () => T.editSettings((s) => {
    s.env = { ...(s.env || {}), CLAUDE_KIT: T.fwd(T.KIT) };
    s.model = cfg.model;
    if (!s.statusLine || /context-guard[\\/]+scripts[\\/]+statusline\.js/.test(s.statusLine.command || '')) s.statusLine = { type: 'command', command: T.statusCmd() };
  }));

  const legacy = results.find((r) => r.fix && r.fix.legacyFolders);
  const cov = results.find((r) => r.fix && r.fix.folders);
  const folders = [...new Set([...(legacy ? legacy.fix.legacyFolders : []), ...(cov ? cov.fix.folders : [])])];
  for (const folder of folders) {
    const f = localFile(folder);
    const before = T.readJSON(f);
    if (before) T.backup(f);
    for (const p of localMissing(folder)) {
      const id = `${p}@${T.MARKET}`;
      let r = T.run('claude', ['plugin', 'install', id, '--scope', 'local'], { cwd: folder });
      if (!r.ok) r = T.run('claude', ['plugin', 'enable', id, '--scope', 'local'], { cwd: folder });
      done.push(`${r.ok ? '✅' : '❌'} ${p} (local) in ${rel(folder)}`);
    }
    const after = T.readJSON(f) || {};
    if (before) {
      // Keep everything else exactly as it was (Headroom's env/hooks first); drop old project-tools entries.
      const ep = { ...(before.enabledPlugins || {}), ...(after.enabledPlugins || {}) };
      for (const k of Object.keys(ep)) if (k.endsWith(`@${T.LEGACY_MARKET}`)) delete ep[k];
      const changed = Object.keys(before).filter((k) => k !== 'enabledPlugins' && JSON.stringify(before[k]) !== JSON.stringify(after[k]));
      fs.writeFileSync(f, JSON.stringify({ ...before, enabledPlugins: ep }, null, 2) + '\n');
      if (changed.length) done.push(`⚠️  ${rel(f)}: ${changed.join(', ')} had changed; restored, only enabledPlugins updated`);
    }
  }
  const repos = results.find((r) => r.fix && r.fix.repos);
  if (repos) for (const root of repos.fix.repos) step(`checkpoint hooks in ${rel(root)}`, process.execPath, [CPJS, 'install'], { cwd: root, shell: false, env: { ...process.env, CLAUDE_KIT: T.KIT } });
  if (kinds.has('remind')) { const r = T.schedule('remind', cfg.reminderTime, cfg.reminderDays); done.push(`${r.ok ? '✅' : '❌'} push reminder scheduled`); }
  if (kinds.has('backuptask')) { const r = T.schedule('backup', cfg.backup.time, null); done.push(`${r.ok ? '✅' : '❌'} backup task scheduled`); }
  if (kinds.has('headroom')) T.installHeadroom((m) => done.push(m));
  if (kinds.has('backupnow')) step('kit backup', process.execPath, [path.join(T.KIT, 'tools', 'backup.js')], { shell: false });
  return done;
}

// ---------- report ----------

function report(title) {
  const icon = { ok: '✅', warn: '⚠️ ', fail: '❌', info: 'ℹ️ ' };
  const out = [`${title}  (${T.today()} · ${T.OS})`, ''];
  for (const r of results) out.push(`${icon[r.status]} ${r.name.padEnd(22)} ${r.detail}`);
  const bad = results.filter((r) => r.status === 'fail' || r.status === 'warn');
  const fixable = bad.filter((r) => r.fix);
  out.push('');
  if (!bad.length) out.push('All good.');
  else {
    out.push(`${bad.length} problem(s).${fixable.length ? ` ${fixable.length} can be fixed with: node "${T.fwd(path.join(T.KIT, 'doctor.js'))}" --all  (ask the user first)` : ''}`);
    const manual = bad.filter((r) => !r.fix);
    if (manual.length) out.push(`Needs the user: ${manual.map((r) => r.name).join(', ')}. See setup-guide.html`);
  }
  process.stdout.write(out.join('\n') + '\n');
  return bad.filter((r) => r.status === 'fail').length;
}

function checks(full) {
  results.length = 0;
  const cfg = T.loadCfg();
  checkKit(cfg);
  checkGlobalMd(cfg);
  if (full) checkTools();
  checkPlugins(full);
  checkSettings(cfg);
  if (full) { checkCoverage(cfg); checkHeadroom(cfg); checkTasks(cfg); checkSkills(); checkGitHub(); selfTest(); }
  return cfg;
}

function save(ok) { try { fs.mkdirSync(path.dirname(STAMP), { recursive: true }); fs.writeFileSync(STAMP, JSON.stringify({ date: T.today(), ok })); } catch {} }

function main() {
  const last = T.readJSON(STAMP);
  const full = FULL || !last || last.date !== T.today() || !last.ok;
  let cfg = checks(full);
  if (!full && results.some((r) => r.status === 'fail')) cfg = checks(true);
  const isFull = results.some((r) => r.name === 'Hooks self-test');
  if (FIX) {
    const done = fixAll(cfg);
    process.stdout.write(`Fixes:\n${done.length ? done.map((d) => '  ' + d).join('\n') : '  nothing to fix automatically'}\n\n`);
    checks(true);
    const bad = report('Setup check after fixes');
    if (done.some((d) => d.startsWith('✅'))) process.stdout.write('Restart Claude Code (or run /reload-plugins) so changes load.\n');
    save(bad === 0); process.exit(bad ? 1 : 0);
  }
  const bad = report(isFull ? 'Daily setup check (full)' : 'Setup check (quick; full check passed today)');
  if (isFull) save(bad === 0);
  process.exit(bad ? 1 : 0);
}

main();
