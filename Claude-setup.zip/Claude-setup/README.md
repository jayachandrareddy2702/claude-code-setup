# claude-kit

My Claude Code working style, packaged so any machine and any codebase gets it in one step.
No project, stack or company content lives here; each codebase gets its own profile through onboarding.

## Install (any OS)

1. Install **Node.js 18+**, **Git** and **Claude Code**
2. Put this folder in your home folder as `Claude-setup` (clone or copy)
3. Run the installer and answer the questions (your current values are shown as defaults):
   - Windows: `install.cmd`
   - macOS / Linux: `./install.sh`
4. Restart Claude Code. Open it in any repo: onboarding starts by itself

Full guide: open `setup-guide.html` in a browser.

## What's inside

| Path | What it is |
|---|---|
| `CLAUDE.md` | Universal rules (rendered per machine into `~/.claude/CLAUDE.md`) |
| `plugins/context-guard` | Context counter, 150K banner, 175K hold, no mid-turn compaction |
| `plugins/checkpoint-guard` | Onboarding + profiles, line budget, test gate, checkpoint book, branch rules, pre-push reviews; skills `plan-mode-workflow` and `project-onboarding` |
| `doctor.js` | Daily check and repair (`--all` fixes) |
| `install.js` (+ `install.cmd` / `install.sh`) | Setup on a new machine |
| `HEADROOM.md` | Set up, check and repair Headroom on any machine (uv, then Python 3.13, then Headroom) |
| `tools/` | Shared helpers, push reminder, daily backup |
| `kit.example.json` | Example machine settings (`kit.json` is created by the installer, not committed) |
| `projects/` | Team repo profiles (local only, not committed) |
| `backup/` | Daily copies of the kit (local only, not committed) |

## Update on another machine

```
cd ~/Claude-setup && git pull && node doctor.js --all
```
