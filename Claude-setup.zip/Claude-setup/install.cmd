@echo off
rem claude-kit installer for Windows. Double-click or run from a terminal.
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 18+ is needed first: https://nodejs.org  - install it, reopen the terminal, run install.cmd again.
  pause
  exit /b 1
)
node "%~dp0install.js" %*
pause
