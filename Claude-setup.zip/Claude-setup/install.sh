#!/bin/sh
# claude-kit installer for macOS and Linux:  ./install.sh
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js 18+ is needed first: https://nodejs.org (or your package manager). Then run ./install.sh again."
  exit 1
fi
exec node "$(cd "$(dirname "$0")" && pwd)/install.js" "$@"
