# HEADROOM.md — Set Up, Check and Repair Headroom (any OS)

Headroom is a local proxy that compresses what Claude Code sends to the model (tool outputs, logs,
search results, tool schemas). Savings come only from input tokens; model replies are never changed,
and if anything fails, traffic passes through uncompressed. Everything runs on this machine.

**On every machine.** This file travels with the kit. Wherever the kit folder is copied or cloned
(another PC, a laptop, Windows, macOS or Linux), the same checks run there:
- **First run** — the installer asks "Use Headroom?" and, if yes, runs Step 1's checks and offers
  Steps 2–4 for whatever is missing on *that* machine
- **Every day** — the doctor re-checks uv, Python 3.13, `headroom` and `headroom doctor`, and repairs
  after the user's yes (`doctor.js --all`). Where Headroom isn't used, it says how to add it
- Nothing here is tied to one machine: no fixed user names or drives; uv, Python and Headroom install
  into the current user's own folders

**When Claude uses this file:** the doctor or the installer reports Headroom, uv or Python 3.13 missing
or broken, `kit.json` has `"headroom": true`, or the user asks for Headroom.

**How Claude runs it:** check everything first (read-only), then show the user every missing step with
its exact command and ask **once**: "Install these now?" Run the commands only after a yes. Never skip
the prerequisites. If a step fails, stop, show the error and the matching fix from Troubleshooting.

---

## Step 1 — Check (read-only, run all three)

| Check | Command | Good result |
|---|---|---|
| uv | `uv --version` | prints a version |
| Python 3.13 | `uv python find 3.13` (or `python --version` without uv) | a 3.13 path / `Python 3.13.x` |
| Headroom | `headroom --version` | prints a version |

Why 3.13: on Python 3.14+ Headroom still saves tokens, but the dashboard's dollar figure stays $0.00
(its pricing library won't install there).

Go to the first step whose check failed. If all pass, skip to Step 5.

---

## Step 2 — Install uv (only if missing)

| OS | Command | Where |
|---|---|---|
| Windows | `powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 \| iex"` | PowerShell, any folder |
| Windows (alternative) | `winget install --id=astral-sh.uv -e` | PowerShell |
| macOS / Linux | `curl -LsSf https://astral.sh/uv/install.sh \| sh` | Terminal |
| macOS (alternative) | `brew install uv` | Terminal |

Then **close and reopen the terminal** (open terminals don't see PATH changes) and check `uv --version`.
If it's still not found: `uv` lives in `%USERPROFILE%\.local\bin` (Windows) or `~/.local/bin`
(macOS/Linux); add that folder to PATH, or run `uv tool update-shell` with its full path.

## Step 3 — Install Python 3.13 (only if missing)

```
uv python install 3.13
```
uv manages this Python itself; it doesn't replace any Python you already have.
Without uv (pip route only): install Python 3.13 from https://www.python.org/downloads/ (Windows: tick
"Add python.exe to PATH").

## Step 4 — Install Headroom

```
uv tool install --python 3.13 "headroom-ai[all]"
uv tool update-shell
```
Reopen the terminal, then check:
```
headroom --version
headroom doctor
```
pip route (no uv): `pip install "headroom-ai[all]"`. The `headroom` command comes only from the PyPI
package; the npm `headroom-ai` package is the TypeScript SDK and has no CLI.

---

## Step 5 — Use it with Claude Code

| Where you run Claude Code | Command (from the project folder) | Notes |
|---|---|---|
| Terminal (CLI) | `headroom wrap claude` | Starts the proxy and launches Claude Code through it; auth and model are kept. Flags: `--code-memory none` skips Serena, `--1m` for 1M context |
| VS Code extension | `headroom wrap vscode-claude` | Then Command Palette → "Developer: Reload Window" |
| Any other client | `headroom proxy --port 8787` | Point its base URL at the printed address |

**Keep the wrapper terminal open the whole session: it is the proxy.** Closing it means plain Claude
Code: no harm, just no savings. Undo any wrap with `headroom unwrap claude` (or `vscode-claude`).

## Step 6 — Verify the savings

1. Use Claude for a few requests (an idle proxy shows nothing)
2. Open `http://127.0.0.1:8787/dashboard` (the URL is printed at start) or run `headroom dashboard`
3. Read **Tokens Saved (total %)**, the headline number. "Content compression %" is only one slice
   and is often a few percent; tool-schema trimming is often the biggest win
4. `headroom savings` gives a summary for your own traffic

---

## How Headroom and the kit work together

- `headroom wrap claude` sets `ENABLE_TOOL_SEARCH=true` and routes traffic through
  `ANTHROPIC_BASE_URL` (default `127.0.0.1:8787`); it may also add a SessionStart self-heal hook and
  `.headroom_wrap_*` files in a project's `.claude` folder
- The kit only ever adds `enabledPlugins` to a `settings.local.json`; it backs the file up and
  restores Headroom's `env` and hook if anything else changed. The doctor checks they are intact and
  never edits them
- context-guard's counter reads the token counts of responses that came through the proxy, so it shows
  the real context after compression

---

## Troubleshooting

| You see | Fix |
|---|---|
| `headroom` / `uv` not recognized | Reopen the terminal. uv: run `uv tool update-shell`. pip on Windows: add the printed `...\Python313\Scripts` folder to PATH (`setx PATH "%PATH%;<folder>"`), then reopen |
| Early requests save only 2–3% | Normal on first run: the text-compression model downloads in the background |
| Dashboard `$ saved` is $0.00 | Python 3.14+: `uv tool install --force --python 3.13 "headroom-ai[all]"`, then restart the proxy |
| "Claude Code is sending all tool definitions eagerly" | Harmless. `headroom wrap claude` sets `ENABLE_TOOL_SEARCH=true` for you |
| `CERTIFICATE_VERIFY_FAILED` on install (corporate network) | `pip install --only-binary headroom-ai headroom-ai`, or install Rust first |
| Port 8787 already in use | `headroom proxy --port <other>` and use the printed URL |
| Something feels wrong | `headroom doctor`; worst case `headroom unwrap claude` restores plain Claude Code |

## Quick reference

| Task | Command |
|---|---|
| Check | `uv --version` · `uv python find 3.13` · `headroom --version` · `headroom doctor` |
| Install | `uv tool install --python 3.13 "headroom-ai[all]"` |
| Wrap Claude Code | `headroom wrap claude` · VS Code: `headroom wrap vscode-claude` |
| Dashboard / savings | `headroom dashboard` · `headroom savings` |
| Update | `headroom update` |
| Undo | `headroom unwrap <agent>` |
