#!/usr/bin/env node
'use strict';
// Daily backup of the kit into <kit>/backup/<date>/, keeping the last kit.json backup.keepDays copies.
// Skips backup/, .git/ and node_modules/. GitHub is the off-machine copy; this one guards against
// accidental edits or deletes inside the kit.

const fs = require('fs');
const path = require('path');
const T = require('./kitlib');

const cfg = T.loadCfg();
const root = path.join(T.KIT, 'backup');
const day = T.today();
const dest = path.join(root, day);
const SKIP = new Set(['backup', '.git', 'node_modules']);

function copy(src, dst) {
  fs.mkdirSync(dst, { recursive: true });
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    if (SKIP.has(e.name)) continue;
    const s = path.join(src, e.name), d = path.join(dst, e.name);
    if (e.isDirectory()) copy(s, d);
    else if (e.isFile()) fs.copyFileSync(s, d);
  }
}

fs.rmSync(dest, { recursive: true, force: true });
copy(T.KIT, dest);
const all = fs.readdirSync(root).filter((d) => /^\d{4}-\d{2}-\d{2}$/.test(d)).sort();
for (const old of all.slice(0, Math.max(0, all.length - (cfg.backup.keepDays || 7)))) fs.rmSync(path.join(root, old), { recursive: true, force: true });
fs.writeFileSync(path.join(root, 'LATEST'), day + '\n');
process.stdout.write(`backup: ${dest} (keeping ${cfg.backup.keepDays || 7})\n`);
