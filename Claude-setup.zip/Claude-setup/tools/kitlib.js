'use strict';
// Shared by install.js and doctor.js: paths, rendering the global CLAUDE.md, settings edits,
// cross-OS scheduling (Windows Task Scheduler, macOS launchd, Linux cron), running commands.

const fs = require('fs');
const os = require('os');
const path = require('path');
const cp = require('child_process');

const KIT = path.resolve(__dirname, '..');
const K = require(path.join(KIT, 'plugins', 'checkpoint-guard', 'scripts', 'kitconf.js'));
const OS = process.platform;                       // win32 | darwin | linux
const WIN = OS === 'win32';
const HOME = os.homedir();
const CLAUDE_DIR = path.join(HOME, '.claude');
const SETTINGS = path.join(CLAUDE_DIR, 'settings.json');
const GLOBAL_MD = path.join(CLAUDE_DIR, 'CLAUDE.md');
const MARKET = 'claude-kit';
const LEGACY_MARKET = 'project-tools';
const PLUGINS = ['context-guard', 'checkpoint-guard'];
const fwd = (p) => String(p).replace(/\\/g, '/');
const today = () => new Intl.DateTimeFormat('en-CA', { timeZone: loadCfg().timezone }).format(new Date());

function loadCfg() { process.env.CLAUDE_KIT = KIT; return K.load(); }
const cfgFile = path.join(KIT, 'kit.json');
const version = () => { try { return fs.readFileSync(path.join(KIT, 'VERSION'), 'utf8').trim(); } catch { return '0'; } };
const pluginVersion = (p) => { try { return JSON.parse(fs.readFileSync(path.join(KIT, 'plugins', p, '.claude-plugin', 'plugin.json'), 'utf8')).version; } catch { return null; } };

function run(cmd, args, opts = {}) {
  const r = cp.spawnSync(cmd, args, { encoding: 'utf8', shell: WIN, timeout: 180000, ...opts });
  return { ok: r.status === 0, out: ((r.stdout || '') + (r.stderr || '')).trim(), missing: !!r.error && r.error.code === 'ENOENT' };
}
const readJSON = (f) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; } };
function backup(f, tag = '') {
  if (!fs.existsSync(f)) return null;
  const b = `${f}.bak-${today()}${tag}`;
  fs.copyFileSync(f, b);
  return b;
}

// ---------- global CLAUDE.md ----------

function render(cfg) {
  const days = (cfg.reminderDays || []).join(', ');
  const vals = {
    KIT: fwd(KIT), KIT_VERSION: version(), MODEL: cfg.model, BRANCH: cfg.branchPrefix,
    PROTECTED: cfg.protectedBranches.map((b) => `\`${b}\``).join(', '), PUSH_TIME: cfg.pushTime, TZ: cfg.timezone,
    NUDGE: cfg.budget.nudge, LIMIT: cfg.budget.limit, HARD: cfg.budget.hard,
    REMINDER_TIME: cfg.reminderTime, REMINDER_DAYS: days || 'no days',
  };
  return fs.readFileSync(path.join(KIT, 'CLAUDE.md'), 'utf8').replace(/\{\{([A-Z_]+)\}\}/g, (m, k) => (k in vals ? String(vals[k]) : m));
}

function globalMdState(cfg) {
  if (!fs.existsSync(GLOBAL_MD)) return 'missing';
  const cur = fs.readFileSync(GLOBAL_MD, 'utf8');
  if (!cur.includes('claude-kit global rules')) return 'foreign';
  return cur === render(cfg) ? 'ok' : 'stale';
}

function writeGlobalMd(cfg) {
  fs.mkdirSync(CLAUDE_DIR, { recursive: true });
  const b = backup(GLOBAL_MD);
  fs.writeFileSync(GLOBAL_MD, render(cfg));
  return b;
}

// ---------- ~/.claude/settings.json ----------

function editSettings(fn) {
  fs.mkdirSync(CLAUDE_DIR, { recursive: true });
  const exists = fs.existsSync(SETTINGS);
  const st = exists ? readJSON(SETTINGS) : {};
  if (st === null) throw new Error('settings.json is not valid JSON; fix it by hand');
  const before = JSON.stringify(st);
  fn(st);
  if (JSON.stringify(st) === before) return false;
  if (exists) backup(SETTINGS, '-kit');
  fs.writeFileSync(SETTINGS, JSON.stringify(st, null, 2) + '\n');
  return true;
}

const statusCmd = () => `node "${fwd(path.join(KIT, 'plugins', 'context-guard', 'scripts', 'statusline.js'))}"`;

// ---------- scheduling ----------

const DAYMAP = { SUN: 0, MON: 1, TUE: 2, WED: 3, THU: 4, FRI: 5, SAT: 6 };
const TASKS = {
  remind: { name: 'Claude kit push reminder', label: 'com.claude-kit.remind', script: 'remind.js' },
  backup: { name: 'Claude kit daily backup', label: 'com.claude-kit.backup', script: 'backup.js' },
};

function schedule(kind, time, days) {
  const t = TASKS[kind];
  const [hh, mm] = time.split(':');
  const script = path.join(KIT, 'tools', t.script);
  const node = process.execPath;
  if (WIN) {
    const tr = `powershell -NoProfile -WindowStyle Hidden -Command "& '${node}' '${script}'"`;
    const args = ['/Create', '/TN', t.name, '/TR', tr, '/ST', `${hh}:${mm}`, '/F'];
    if (days && days.length < 7) args.push('/SC', 'WEEKLY', '/D', days.join(',')); else args.push('/SC', 'DAILY');
    return run('schtasks', args, { shell: false });
  }
  if (OS === 'darwin') {
    const dir = path.join(HOME, 'Library', 'LaunchAgents');
    fs.mkdirSync(dir, { recursive: true });
    const plist = path.join(dir, `${t.label}.plist`);
    const cal = (days && days.length < 7 ? days.map((d) => DAYMAP[d]) : [null])
      .map((d) => `<dict>${d === null ? '' : `<key>Weekday</key><integer>${d}</integer>`}<key>Hour</key><integer>${+hh}</integer><key>Minute</key><integer>${+mm}</integer></dict>`).join('');
    fs.writeFileSync(plist, `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict><key>Label</key><string>${t.label}</string>
<key>ProgramArguments</key><array><string>${node}</string><string>${script}</string></array>
<key>StartCalendarInterval</key><array>${cal}</array></dict></plist>
`);
    run('launchctl', ['unload', plist], { shell: false });
    return run('launchctl', ['load', '-w', plist], { shell: false });
  }
  // linux / other unix: crontab
  const cur = run('crontab', ['-l'], { shell: false });
  const lines = (cur.ok ? cur.out : '').split('\n').filter((l) => l && !l.includes(`# ${t.label}`));
  const dow = days && days.length < 7 ? days.map((d) => DAYMAP[d]).join(',') : '*';
  lines.push(`${+mm} ${+hh} * * ${dow} "${node}" "${script}" # ${t.label}`);
  return run('sh', ['-c', `printf '%s\\n' "$0" | crontab -`, lines.join('\n')], { shell: false });
}

function scheduled(kind) {
  const t = TASKS[kind];
  if (WIN) return run('schtasks', ['/Query', '/TN', t.name], { shell: false }).ok;
  if (OS === 'darwin') return fs.existsSync(path.join(HOME, 'Library', 'LaunchAgents', `${t.label}.plist`));
  const cur = run('crontab', ['-l'], { shell: false });
  return cur.ok && cur.out.includes(`# ${t.label}`);
}

function unschedule(kind) {
  const t = TASKS[kind];
  if (WIN) return run('schtasks', ['/Delete', '/TN', t.name, '/F'], { shell: false });
  if (OS === 'darwin') { const p = path.join(HOME, 'Library', 'LaunchAgents', `${t.label}.plist`); run('launchctl', ['unload', p], { shell: false }); try { fs.unlinkSync(p); } catch {} return { ok: true }; }
  const cur = run('crontab', ['-l'], { shell: false });
  const lines = (cur.ok ? cur.out : '').split('\n').filter((l) => l && !l.includes(`# ${t.label}`));
  return run('sh', ['-c', `printf '%s\\n' "$0" | crontab -`, lines.join('\n')], { shell: false });
}

// ---------- notifications ----------

function notify(title, text) {
  if (WIN) {
    const ps = `(New-Object -ComObject WScript.Shell).Popup(${JSON.stringify(text)}, 0, ${JSON.stringify(title)}, 48) | Out-Null`;
    return run('powershell', ['-NoProfile', '-Command', ps], { shell: false });
  }
  if (OS === 'darwin') return run('osascript', ['-e', `display dialog ${JSON.stringify(text)} with title ${JSON.stringify(title)} buttons {"OK"} with icon caution`], { shell: false });
  const r = run('notify-send', ['-u', 'critical', title, text], { shell: false });
  if (!r.ok) process.stdout.write(`${title}\n${text}\n`);
  return r;
}

// ---------- workspace discovery ----------

function discover(cfg) {
  const skip = new Set(['node_modules', 'CLAUDE', 'Claude-setup', 'claude-plugins', '_claude-kit']);
  const top = [], repos = [];
  for (const rootDir of cfg.workspaceRoots || []) {
    if (!fs.existsSync(rootDir)) continue;
    if (fs.existsSync(path.join(rootDir, '.git'))) { repos.push(rootDir); continue; }
    let kids = [];
    try { kids = fs.readdirSync(rootDir, { withFileTypes: true }); } catch { continue; }
    for (const k of kids) if (k.isDirectory() && !k.name.startsWith('.') && !skip.has(k.name) && path.join(rootDir, k.name) !== KIT) top.push(path.join(rootDir, k.name));
    const walk = (dir, depth) => {
      if (path.resolve(dir) === KIT) return;
      if (fs.existsSync(path.join(dir, '.git'))) { repos.push(dir); return; }
      if (depth >= 4) return;
      let ks = [];
      try { ks = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
      for (const k of ks) if (k.isDirectory() && !k.name.startsWith('.') && !skip.has(k.name)) walk(path.join(dir, k.name), depth + 1);
    };
    for (const t of top.filter((d) => d.startsWith(rootDir))) walk(t, 1);
  }
  return { top, repos, folders: [...new Set([...top, ...repos])] };
}


// ---------- Headroom (see HEADROOM.md) ----------

function uvPath() {
  if (run('uv', ['--version']).ok) return 'uv';
  const p = path.join(HOME, '.local', 'bin', WIN ? 'uv.exe' : 'uv');
  return fs.existsSync(p) ? p : null;
}

function headroomState() {
  const uv = uvPath();
  const uvVer = uv ? run(uv, ['--version'], { shell: WIN && uv === 'uv' }).out : null;
  let py = null;
  if (uv) { const r = run(uv, ['python', 'find', '3.13'], { shell: WIN && uv === 'uv' }); if (r.ok) py = r.out.split('\n').pop(); }
  if (!py) { const r = run(WIN ? 'python' : 'python3', ['--version']); if (r.ok && /3\.13\./.test(r.out)) py = r.out; }
  const hr = run('headroom', ['--version']);
  const doc = hr.ok ? run('headroom', ['doctor'], { timeout: 120000 }) : { ok: false };
  return { uv, uvVer, py, headroom: hr.ok ? hr.out.split('\n')[0] : null, doctorOk: doc.ok };
}

// Install whatever is missing, in order: uv -> Python 3.13 -> Headroom. Call only after the user's yes.
function installHeadroom(log) {
  let st = headroomState();
  if (!st.uv) {
    const r = WIN
      ? run('powershell', ['-ExecutionPolicy', 'ByPass', '-c', 'irm https://astral.sh/uv/install.ps1 | iex'], { shell: false, timeout: 600000 })
      : run('sh', ['-c', 'curl -LsSf https://astral.sh/uv/install.sh | sh'], { shell: false, timeout: 600000 });
    log(`${r.ok ? '✅' : '❌'} install uv${r.ok ? '' : ': ' + r.out.split('\n').slice(-2).join(' ')}`);
    st = headroomState();
    if (!st.uv) { log('❌ uv still not found; reopen the terminal and run this again (HEADROOM.md step 2)'); return st; }
  }
  const uvOpts = { shell: WIN && st.uv === 'uv', timeout: 900000 };
  if (!st.py) {
    const r = run(st.uv, ['python', 'install', '3.13'], uvOpts);
    log(`${r.ok ? '✅' : '❌'} install Python 3.13 (uv)${r.ok ? '' : ': ' + r.out.split('\n').pop()}`);
  }
  if (!st.headroom) {
    const r = run(st.uv, ['tool', 'install', '--python', '3.13', 'headroom-ai[all]'], uvOpts);
    log(`${r.ok ? '✅' : '❌'} install Headroom${r.ok ? '' : ': ' + r.out.split('\n').slice(-2).join(' ') + ' (corporate SSL? see HEADROOM.md troubleshooting)'}`);
    run(st.uv, ['tool', 'update-shell'], uvOpts);
  }
  st = headroomState();
  log(st.headroom ? `✅ ${st.headroom}${st.doctorOk ? ' · headroom doctor passed' : ' · run `headroom doctor` in a new terminal'}` : '⚠️  Headroom installed but not on PATH yet: reopen the terminal, then `headroom doctor`');
  return st;
}

module.exports = {
  uvPath, headroomState, installHeadroom,
  KIT, K, OS, WIN, HOME, CLAUDE_DIR, SETTINGS, GLOBAL_MD, MARKET, LEGACY_MARKET, PLUGINS, cfgFile,
  fwd, today, loadCfg, version, pluginVersion, run, readJSON, backup,
  render, globalMdState, writeGlobalMd, editSettings, statusCmd, schedule, scheduled, unschedule, notify, discover, TASKS,
};
