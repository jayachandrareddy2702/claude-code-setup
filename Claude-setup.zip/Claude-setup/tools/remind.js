#!/usr/bin/env node
'use strict';
// End-of-day push reminder (scheduled by install.js / doctor.js at kit.json reminderTime).
// Lists unpushed commits in every repo of the workspace roots that has checkpoint-guard. Never pushes.

const fs = require('fs');
const path = require('path');
const T = require('./kitlib');

const cfg = T.loadCfg();
const cp = path.join(T.KIT, 'plugins', 'checkpoint-guard', 'scripts', 'cp.js');
const lines = [];
for (const repo of T.discover(cfg).repos) {
  const gd = T.run('git', ['rev-parse', '--absolute-git-dir'], { cwd: repo, shell: false }).out;
  if (!gd || !fs.existsSync(path.join(gd, 'checkpoint-guard', 'installed'))) continue;
  T.run(process.execPath, [cp, 'sync'], { cwd: repo, shell: false });
  const br = T.run('git', ['rev-parse', '--abbrev-ref', 'HEAD'], { cwd: repo, shell: false }).out;
  const up = T.run('git', ['rev-parse', '--abbrev-ref', '--symbolic-full-name', '@{u}'], { cwd: repo, shell: false }).ok;
  const n = T.run('git', up ? ['rev-list', '--count', '@{u}..HEAD'] : ['rev-list', '--count', 'HEAD', '--not', '--remotes'], { cwd: repo, shell: false }).out;
  if (+n > 0) lines.push(`${repo}  [${br}]  ${n} unpushed`);
}
if (lines.length) {
  T.notify('Push reminder', `Mandatory end-of-day push before ${cfg.pushTime} (${cfg.timezone}):\n\n${lines.join('\n')}\n\nReview (rule 3.9), push each feature branch, then close the day.`);
}
