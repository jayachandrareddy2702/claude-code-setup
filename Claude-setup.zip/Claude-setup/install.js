#!/usr/bin/env node
'use strict';
// claude-kit installer — Windows, macOS and Linux. Run it on every machine after copying or cloning the kit:
//   Windows:  install.cmd        macOS/Linux:  ./install.sh        (or: node install.js)
// It asks this machine's settings (showing your current values), then sets up the global CLAUDE.md,
// the plugins, the status line, the model, the reminder and backup tasks, optional Headroom,
// and finishes with a doctor run. Safe to run again: it only changes what differs, with backups.
//   --yes   accept the shown defaults without asking (for re-runs)

const fs = require('fs');
const path = require('path');
const readline = require('readline');
const T = require('./tools/kitlib');

const YES = process.argv.includes('--yes');
const say = (s = '') => process.stdout.write(s + '\n');
const step = (s) => say(`\n▶ ${s}`);
const ok = (s) => say(`  ✅ ${s}`);
const warn = (s) => say(`  ⚠️  ${s}`);

let rl = null;
function ask(q, def) {
  if (YES) { say(`  ${q} [${def}] → ${def}`); return Promise.resolve(String(def)); }
  rl = rl || readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise((res) => rl.question(`  ${q}${def !== undefined && def !== '' ? ` [${def}]` : ''}: `, (a) => res(a.trim() === '' ? String(def ?? '') : a.trim())));
}
const yes = async (q, def = 'y') => /^y/i.test(await ask(`${q} (y/n)`, def));
const list = (s) => String(s).split(',').map((x) => x.trim()).filter(Boolean);

function defaultRoots() {
  const guesses = [path.join(path.dirname(T.KIT), 'project'), 'C:\\project', path.join(T.HOME, 'project'), path.join(T.HOME, 'projects'), path.join(T.HOME, 'code')];
  return guesses.filter((g, i) => guesses.indexOf(g) === i && fs.existsSync(g));
}

async function settings() {
  const cur = T.loadCfg();
  const gName = T.run('git', ['config', '--global', 'user.name'], { shell: false }).out;
  const gMail = T.run('git', ['config', '--global', 'user.email'], { shell: false }).out;
  const hrHave = T.run('headroom', ['--version']).ok;
  let c;
  for (;;) {
    say('\nThis machine\'s settings (Enter keeps the value in brackets):');
    c = { version: 1 };
    c.workspaceRoots = list(await ask('Project folders to cover, comma-separated', (cur.workspaceRoots.length ? cur.workspaceRoots : defaultRoots()).join(', ') || path.join(T.HOME, 'project')));
    c.git = { name: await ask('Git name for commits on this machine', cur.git.name || gName), email: await ask('Git email for commits on this machine', cur.git.email || gMail) };
    c.timezone = await ask('Timezone (IANA name)', cur.timezone);
    c.pushTime = await ask('Mandatory end-of-day push time (HH:MM)', cur.pushTime);
    c.reminderTime = await ask('Desktop reminder time (HH:MM)', cur.reminderTime);
    c.reminderDays = list((await ask('Reminder days', cur.reminderDays.join(','))).toUpperCase());
    c.branchPrefix = await ask('Feature branch prefix', cur.branchPrefix);
    c.protectedBranches = list(await ask('Protected branches (never commit/push)', cur.protectedBranches.join(',')));
    c.budget = { nudge: +(await ask('Line budget: suggest a commit at', cur.budget.nudge)), limit: +(await ask('Line budget: block edits at', cur.budget.limit)), hard: +(await ask('Line budget: absolute maximum (approved edge cases)', cur.budget.hard)) };
    c.model = await ask('Default model (opusplan = Opus planning, Sonnet executing)', cur.model);
    c.lint = /^y/i.test(await ask('Lint gate on by default? (y/n)', cur.lint ? 'y' : 'n'));
    c.testTimeoutMin = +(await ask('Test time limit per commit, minutes', cur.testTimeoutMin));
    c.backup = { keepDays: +(await ask('Daily kit backups to keep', cur.backup.keepDays)), time: await ask('Daily backup time (HH:MM)', cur.backup.time) };
    c.headroom = /^y/i.test(await ask(`Use Headroom (context compression proxy)? ${hrHave ? '(installed)' : '(not installed; can install now)'} (y/n)`, cur.headroom || hrHave ? 'y' : 'n'));
    const bad = [];
    if (!c.git.email || !/@/.test(c.git.email)) bad.push('a Git email is needed (reviews cover "our changes" by this email)');
    if (!(c.budget.nudge < c.budget.limit && c.budget.limit <= c.budget.hard)) bad.push('line budget must be suggest < block <= maximum');
    for (const t of [c.pushTime, c.reminderTime, c.backup.time]) if (!/^\d{1,2}:\d{2}$/.test(t)) bad.push(`"${t}" is not HH:MM`);
    say('\nSummary:');
    say(JSON.stringify(c, null, 2).split('\n').map((l) => '  ' + l).join('\n'));
    if (bad.length) { bad.forEach(warn); if (YES) throw new Error('fix the settings above (run without --yes)'); continue; }
    if (await yes('Comfortable with these settings, or change any? y = continue, n = edit again', 'y')) break;
  }
  return c;
}

function claudeCli() {
  const r = T.run('claude', ['--version']);
  if (r.ok) return true;
  warn('Claude Code (the `claude` command) was not found. Install it first: https://code.claude.com/docs/en/setup');
  warn('Then run this installer again. Continuing with the parts that don\'t need it.');
  return false;
}

async function main() {
  say(`claude-kit ${T.version()} installer · ${T.OS} · kit at ${T.KIT}`);

  step('Checking tools');
  const nodeMajor = +process.versions.node.split('.')[0];
  if (nodeMajor < 18) throw new Error(`Node ${process.versions.node} is too old; install Node 18 or newer from https://nodejs.org`);
  ok(`node ${process.versions.node}`);
  const g = T.run('git', ['--version'], { shell: false });
  if (!g.ok) throw new Error('git not found; install it from https://git-scm.com/downloads');
  ok(g.out);
  const hasClaude = claudeCli();
  if (hasClaude) ok(T.run('claude', ['--version']).out.split('\n')[0]);

  step('Machine settings');
  const c = await settings();
  T.backup(T.cfgFile);
  fs.writeFileSync(T.cfgFile, JSON.stringify(c, null, 2) + '\n');
  ok(`saved ${T.cfgFile}`);
  const cfg = T.loadCfg();

  step('Git identity');
  for (const [k, v] of [['user.name', c.git.name], ['user.email', c.git.email]]) {
    const cur = T.run('git', ['config', '--global', k], { shell: false }).out;
    if (v && cur !== v) { T.run('git', ['config', '--global', k, v], { shell: false }); ok(`git ${k} = ${v}${cur ? ` (was ${cur})` : ''}`); } else ok(`git ${k} = ${cur}`);
  }

  step('Global rules (~/.claude/CLAUDE.md)');
  const st = T.globalMdState(cfg);
  if (st === 'foreign' && !(await yes('A CLAUDE.md that is not from the kit exists; replace it (a backup is kept)?', 'y'))) warn('kept your existing global CLAUDE.md');
  else if (st !== 'ok') { const b = T.writeGlobalMd(cfg); ok(`written for this machine${b ? ` (backup ${path.basename(b)})` : ''}`); } else ok('already current');

  step('Claude Code settings (~/.claude/settings.json)');
  let foreignStatus = false;
  T.editSettings((s) => {
    s.env = { ...(s.env || {}), CLAUDE_KIT: T.fwd(T.KIT) };
    if (!s.statusLine || /context-guard[\\/]+scripts[\\/]+statusline\.js/.test(s.statusLine.command || '')) s.statusLine = { type: 'command', command: T.statusCmd() };
    else foreignStatus = true;
    s.model = c.model;
  });
  ok(`CLAUDE_KIT, model ${c.model}${foreignStatus ? '' : ', status line'}`);
  if (foreignStatus) warn('you have your own status line; left it alone (the kit counter needs it: see setup-guide.html)');

  if (hasClaude) {
    step('Plugins');
    const ml = T.run('claude', ['plugin', 'marketplace', 'list']).out;
    if (ml.includes(T.LEGACY_MARKET) && (await yes(`Remove the old "${T.LEGACY_MARKET}" marketplace (C:\\project\\claude-plugins) so its hooks don't run twice?`, 'y'))) {
      const r = T.run('claude', ['plugin', 'marketplace', 'remove', T.LEGACY_MARKET]);
      r.ok ? ok('old marketplace removed') : warn(r.out);
    }
    const r1 = ml.includes(T.MARKET) ? T.run('claude', ['plugin', 'marketplace', 'update', T.MARKET]) : T.run('claude', ['plugin', 'marketplace', 'add', T.KIT]);
    r1.ok ? ok(`marketplace ${T.MARKET}`) : warn(r1.out);
    for (const p of T.PLUGINS) {
      let r = T.run('claude', ['plugin', 'install', `${p}@${T.MARKET}`, '--scope', 'user']);
      if (!r.ok) r = T.run('claude', ['plugin', 'update', `${p}@${T.MARKET}`]);
      r.ok ? ok(`${p} ${T.pluginVersion(p)}`) : warn(`${p}: ${r.out.split('\n').pop()}`);
    }
  }

  if (c.headroom) {
    step('Headroom (HEADROOM.md): checking uv, Python 3.13, Headroom');
    const st = T.headroomState();
    ok(`uv: ${st.uvVer || 'missing'} · Python 3.13: ${st.py ? 'found' : 'missing'} · Headroom: ${st.headroom || 'missing'}`);
    const todo = [!st.uv && 'uv', !st.py && 'Python 3.13 (via uv)', !st.headroom && 'Headroom (uv tool install --python 3.13 "headroom-ai[all]")'].filter(Boolean);
    if (!todo.length) ok(st.doctorOk ? 'headroom doctor passed' : 'installed; run `headroom doctor` to finish');
    else if (await yes(`Install now, in this order: ${todo.join(' → ')}?`, 'y')) T.installHeadroom((m) => say('  ' + m));
    else warn('skipped: follow HEADROOM.md when you are ready');
    say('  Start Claude Code through Headroom:  headroom wrap claude   (VS Code: headroom wrap vscode-claude)');
  }

  step('Scheduled tasks');
  const r2 = T.schedule('remind', c.reminderTime, c.reminderDays);
  r2.ok ? ok(`push reminder ${c.reminderTime} on ${c.reminderDays.join(',')}`) : warn(`reminder: ${r2.out}`);
  const r3 = T.schedule('backup', c.backup.time, null);
  r3.ok ? ok(`daily backup at ${c.backup.time}`) : warn(`backup: ${r3.out}`);
  T.run(process.execPath, [path.join(T.KIT, 'tools', 'backup.js')], { shell: false });
  ok('first backup made');

  step('Doctor (every folder and repo in your project folders)');
  const d = T.run(process.execPath, [path.join(T.KIT, 'doctor.js'), '--all'], { shell: false, timeout: 900000 });
  say(d.out.split('\n').map((l) => '  ' + l).join('\n'));

  step('Done');
  say('  Restart Claude Code (or run /reload-plugins) so the plugins and rules load.');
  say('  Each new repo is onboarded automatically the first time you open Claude in it.');
  if (!fs.existsSync(path.join(T.KIT, '.git'))) {
    say('\n  Keep the kit on GitHub (private repo, personal account) so other machines can pull it:');
    say(`    cd "${T.KIT}"\n    git init -b main && git add -A && git commit -m "claude-kit ${T.version()}"`);
    say('    git remote add origin https://github.com/<you>/claude-kit.git && git push -u origin main');
  }
  if (rl) rl.close();
}

main().catch((e) => { say(`\n❌ ${e.message}`); if (rl) rl.close(); process.exit(1); });
